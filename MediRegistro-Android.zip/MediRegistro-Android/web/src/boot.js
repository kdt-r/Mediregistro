'use strict';
// Pegamento del navegador: sustituye al servidor web. Las "páginas" las genera router.js dentro del propio teléfono.
const router = require('./router');

const puente = window.AndroidBridge; // lo inyecta MainActivity (guardar archivos, imprimir)

const aObjeto = (params) => {
  const o = {};
  for (const [k, v] of params) {
    if (k in o) o[k] = [].concat(o[k], v); else o[k] = v;
  }
  return o;
};

/* ---------- Ajustes al HTML para que funcione sin servidor ---------- */
function adaptar(html) {
  return html
    .replace(/location\.href\s*=\s*('[^']*'|"[^"]*")/g, 'mr.ir($1)')
    .replace(/location\.reload\(\)/g, 'mr.recargar()')
    .replace(/window\.print\(\)/g, 'mr.imprimir()')
    .replace(/accept="\.sqlite"/g, 'accept="*/*"');
}

function pintar(html, conservarScroll) {
  const y = window.scrollY;
  const doc = new DOMParser().parseFromString(adaptar(html), 'text/html');
  const scripts = Array.from(doc.querySelectorAll('script')).map((s) => s.textContent);
  doc.querySelectorAll('script').forEach((s) => s.remove());
  document.title = doc.title || 'MediRegistro';
  document.body.innerHTML = doc.body.innerHTML;
  window.scrollTo(0, conservarScroll ? y : 0);
  // eval indirecto: los const/let de cada página no chocan con los de la anterior
  scripts.forEach((c) => { try { (0, eval)(c); } catch (e) { console.error(e); } });
}

/* ---------- Archivos (copia de seguridad, Excel) ---------- */
const aBytes = (c) => (typeof c === 'string' ? new TextEncoder().encode(c) : c);
function base64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
function entregarArchivo(resp) {
  const nombre = (/filename="([^"]+)"/.exec(resp.headers['content-disposition']) || [])[1] || 'archivo';
  const mime = String(resp.headers['content-type'] || 'application/octet-stream').split(';')[0];
  const bytes = aBytes(resp.cuerpo);
  if (puente && puente.saveFile) { puente.saveFile(nombre, mime, base64(bytes)); return; }
  const a = document.createElement('a'); // respaldo para probar en un navegador de escritorio
  a.href = URL.createObjectURL(new Blob([bytes], { type: mime })); a.download = nombre;
  document.body.appendChild(a); a.click(); a.remove();
}

/* ---------- Navegación ---------- */
// modo: 'push' (nueva entrada del historial), 'replace' o 'ninguno'
async function ir(url, { modo = 'push', metodo = 'GET', cuerpo = {}, scroll = false } = {}) {
  const u = new URL(url, location.origin);
  const resp = await router.atender({ method: metodo, path: u.pathname, query: aObjeto(u.searchParams), body: cuerpo, headers: {} });
  if (resp.status >= 300 && resp.status < 400 && resp.headers.location) return ir(resp.headers.location, { modo: modo === 'ninguno' ? 'replace' : modo });
  if (resp.headers['content-disposition']) return entregarArchivo(resp);
  pintar(String(resp.cuerpo), scroll);
  const destino = u.pathname + u.search;
  if (modo === 'push' && destino !== location.pathname + location.search) history.pushState({}, '', destino);
  else if (modo === 'replace') history.replaceState({}, '', destino);
}

document.addEventListener('click', (e) => {
  if (e.defaultPrevented || e.button !== 0) return;
  const a = e.target.closest && e.target.closest('a[href]');
  if (!a) return;
  const href = a.getAttribute('href');
  if (!href || href[0] === '#' || /^[a-z][a-z0-9+.-]*:/i.test(href)) return; // http, mailto, tel: los atiende Android
  e.preventDefault();
  ir(href);
});

document.addEventListener('submit', (e) => {
  const f = e.target;
  if (!f || f.tagName !== 'FORM') return;
  e.preventDefault();
  const params = new URLSearchParams(new FormData(f));
  const destino = new URL(f.getAttribute('action') || location.pathname, location.origin);
  if ((f.getAttribute('method') || 'get').toUpperCase() === 'POST') {
    ir(destino.pathname + destino.search, { metodo: 'POST', cuerpo: aObjeto(params), modo: 'push' });
  } else {
    ir(destino.pathname + '?' + params.toString());
  }
});

window.addEventListener('popstate', () => ir(location.pathname + location.search, { modo: 'ninguno' }));

// Las páginas llaman a fetch('/panel/restaurar', …): se atiende localmente
const fetchOriginal = window.fetch.bind(window);
window.fetch = async (input, init = {}) => {
  const u = new URL(typeof input === 'string' ? input : input.url, location.origin);
  if (u.origin !== location.origin || !u.pathname.startsWith('/panel/')) return fetchOriginal(input, init);
  const cab = {};
  Object.entries(init.headers || {}).forEach(([k, v]) => { cab[k.toLowerCase()] = v; });
  let cuerpo = init.body;
  if (cuerpo instanceof ArrayBuffer) cuerpo = new Uint8Array(cuerpo);
  else if (ArrayBuffer.isView(cuerpo)) cuerpo = new Uint8Array(cuerpo.buffer, cuerpo.byteOffset, cuerpo.byteLength);
  const r = await router.atender({ method: (init.method || 'GET').toUpperCase(), path: u.pathname, query: aObjeto(u.searchParams), body: cuerpo, headers: cab });
  return new Response(r.cuerpo, { status: r.status });
};

window.mr = {
  ir: (url) => ir(url),
  // La página "Registros de hoy" se refresca sola cada 30 s; solo actúa si sigue en esa pantalla
  recargar: () => { if (location.pathname === '/hoy') ir(location.pathname + location.search, { modo: 'ninguno', scroll: true }); },
  imprimir: () => (puente && puente.print ? puente.print() : window.print()),
};

/* ---------- Arranque ---------- */
async function arrancar() {
  try {
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
    const SQL = await window.initSqlJs({ locateFile: (f) => '/' + f });
    await router.iniciar(SQL);
    await ir('/', { modo: 'replace' });
  } catch (e) {
    console.error(e);
    const c = document.getElementById('mr-carga');
    if (c) c.textContent = 'No se pudo iniciar MediRegistro: ' + (e && e.message ? e.message : e);
  }
}
arrancar();
