'use strict';
// Ejecuta el bundle real (el mismo que va en la app) contra SQLite y recorre los flujos principales.
const vm = require('vm');
const assert = require('assert');
const { webcrypto } = require('crypto');
const { empaquetar } = require('../build-web.js');
const shim = require('./sqljs-shim.js');

const mundo = () => {
  const ctx = vm.createContext({ console, crypto: webcrypto, TextEncoder, TextDecoder, setTimeout, Uint8Array, Promise, Date, JSON, Math, URLSearchParams, Array, Object, String, Number, Error, parseInt, encodeURIComponent, decodeURIComponent });
  vm.runInContext(empaquetar(), ctx);
  const R = ctx.MediRegistro.require;
  return { R, router: R('router'), Store: R('store'), ESP: R('especialidades'), db: R('db') };
};

let n = 0;
const ok = (c, m) => { assert.ok(c, m); n++; console.log('  ✔ ' + m); };
const csrfDe = (html) => (/name="csrf" value="([a-f0-9]+)"/.exec(html) || [])[1];
const pedir = (w, method, path, { query = {}, body = {}, headers = {} } = {}) => w.router.atender({ method, path, query, body, headers });

(async () => {
  const w = mundo();
  await w.router.iniciar(shim);

  console.log('Instalación');
  let r = await pedir(w, 'GET', '/');
  ok(r.status === 302 && r.headers.location === '/instalar', 'sin configurar, redirige al asistente');
  r = await pedir(w, 'GET', '/instalar');
  ok(r.status === 200 && /<form/.test(r.cuerpo), 'el asistente se muestra');
  const csrf = csrfDe(r.cuerpo); ok(!!csrf, 'la página trae token CSRF');
  r = await pedir(w, 'POST', '/instalar', { body: { admin_user: 'admin' } });
  ok(r.status === 403, 'POST sin CSRF es rechazado');
  r = await pedir(w, 'POST', '/instalar', { body: { csrf, admin_user: 'ad', admin_pass: '123', admin_pass2: '1' } });
  ok(r.status === 400 && /usuario debe tener/.test(r.cuerpo), 'valida usuario y contraseña débiles');
  r = await pedir(w, 'POST', '/instalar', { body: { csrf, institucion_nombre: 'Clínica Prueba', telefono_urgencias: '911', admin_user: 'admin01', admin_pass: 'clave-segura-1', admin_pass2: 'clave-segura-1' } });
  ok(r.status === 302 && r.headers.location === '/', 'instala y entra como administrador');
  const cfgGuardada = await w.Store.get('config');
  ok(/^pbkdf2\$/.test(cfgGuardada.admin_hash) && !JSON.stringify(cfgGuardada).includes('clave-segura-1'), 'la contraseña se guarda solo como hash PBKDF2');

  console.log('Panel');
  r = await pedir(w, 'GET', '/');
  ok(r.status === 200 && /Clínica Prueba/.test(r.cuerpo), 'inicio del administrador muestra la institución');
  for (const ruta of ['/nuevo', '/panel', '/hoy', '/panel/base', '/panel/ajustes']) {
    r = await pedir(w, 'GET', ruta); ok(r.status === 200, `GET ${ruta} → 200`);
  }

  console.log('Registro de pacientes (todas las especialidades)');
  const token = csrfDe((await pedir(w, 'GET', '/nuevo')).cuerpo) || csrf;
  let folios = [];
  for (const esp of w.ESP) {
    const f = await pedir(w, 'GET', '/registro/' + esp.slug);
    assert.strictEqual(f.status, 200, 'formulario ' + esp.slug);
    const body = { csrf: token };
    const llenar = (c) => {
      if (c.type === 'checks') { body[c.name] = [].concat(c.options[0]).map((o) => (Array.isArray(o) ? o[0] : o)); body[c.name] = [Array.isArray(c.options[0]) ? c.options[0][0] : c.options[0]]; return; }
      if (c.type === 'select') body[c.name] = Array.isArray(c.options[0]) ? c.options[0][0] : c.options[0];
      else if (c.type === 'date') body[c.name] = '1990-05-17';
      else if (c.type === 'number') body[c.name] = String(c.min !== undefined ? c.min : 1);
      else if (c.type === 'email') body[c.name] = 'a@b.co';
      else body[c.name] = 'Prueba ' + c.name;
    };
    w.ESP.comunes.forEach(llenar);
    esp.secciones.forEach((s) => s.campos.forEach(llenar));
    body.nombres = 'Ana'; body.apellidos = 'Pérez ' + esp.slug;
    r = await pedir(w, 'POST', '/registro/' + esp.slug, { body });
    assert.strictEqual(r.status, 302, `${esp.slug}: ${String(r.cuerpo).slice(0, 300)}`);
    folios.push(/folio=([^&]+)/.exec(r.headers.location)[1]);
  }
  ok(folios.length === w.ESP.length && new Set(folios).size === folios.length, `se registró un paciente en cada una de las ${w.ESP.length} especialidades, con folios únicos`);
  r = await pedir(w, 'POST', '/registro/' + w.ESP[0].slug, { body: { csrf: token, nombres: '' } });
  ok(r.status === 400 && /obligatorio/.test(r.cuerpo), 'campos obligatorios vacíos se rechazan');
  r = await pedir(w, 'GET', '/gracias', { query: { folio: folios[0], esp: w.ESP[0].nombre } });
  ok(r.status === 200 && r.cuerpo.includes(folios[0]), 'pantalla de comprobante con el folio');
  r = await pedir(w, 'GET', '/registro/no-existe'); ok(r.status === 404, 'ruta inexistente → 404');

  console.log('Consultas y exportación');
  r = await pedir(w, 'GET', '/panel', { query: { q: 'Pérez' } });
  ok(r.status === 200 && r.cuerpo.includes('Ana Pérez'), 'búsqueda por nombre encuentra pacientes');
  r = await pedir(w, 'GET', '/panel', { query: { q: 'zzzz-nada' } });
  ok(!r.cuerpo.includes('Ana Pérez'), 'búsqueda sin coincidencias no devuelve pacientes');
  r = await pedir(w, 'GET', '/panel/registro/1'); ok(r.status === 200 && r.cuerpo.includes('Ana'), 'ficha del paciente');
  r = await pedir(w, 'GET', '/hoy'); ok(r.cuerpo.includes('Ana Pérez'), '"Registros de hoy" lista los nuevos');
  r = await pedir(w, 'GET', '/panel/exportar.csv');
  ok(r.status === 200 && /attachment; filename="registros_.*\.csv"/.test(r.headers['content-disposition']) && r.cuerpo.startsWith('\uFEFF"Folio"') && r.cuerpo.split('\r\n').length === w.ESP.length + 1, 'exporta CSV con BOM y una fila por registro');

  console.log('Copia de seguridad');
  r = await pedir(w, 'GET', '/panel/respaldo');
  ok(r.status === 200 && r.cuerpo instanceof Uint8Array && /copia-mediregistro-\d{4}-\d{2}-\d{2}\.sqlite/.test(r.headers['content-disposition']), 'genera archivo de copia');
  const copia = r.cuerpo;
  r = await pedir(w, 'POST', '/panel/restaurar', { body: new Uint8Array([1, 2, 3]), headers: { 'x-csrf': token } });
  ok(r.status === 400 && /No se pudo restaurar/.test(r.cuerpo), 'un archivo que no es copia se rechaza');
  // Se añade un paciente y luego se restaura la copia anterior: debe desaparecer
  const extra = { csrf: token };
  [...w.ESP.comunes, ...w.ESP[0].secciones.flatMap((s) => s.campos)].forEach((c) => { extra[c.name] = c.type === 'date' ? '1980-01-01' : c.type === 'select' ? (Array.isArray(c.options[0]) ? c.options[0][0] : c.options[0]) : c.type === 'checks' ? [Array.isArray(c.options[0]) ? c.options[0][0] : c.options[0]] : c.type === 'number' ? String(c.min || 1) : c.type === 'email' ? 'x@y.zz' : 'Dato'; });
  extra.nombres = 'Zacarías'; extra.apellidos = 'Temporal';
  await pedir(w, 'POST', '/registro/' + w.ESP[0].slug, { body: extra });
  ok((await pedir(w, 'GET', '/panel', { query: { q: 'Zacarías' } })).cuerpo.includes('Zacarías Temporal'), 'paciente temporal guardado');
  r = await pedir(w, 'POST', '/panel/restaurar', { body: copia, headers: { 'x-csrf': token } });
  ok(r.status === 200 && /correctamente/.test(r.cuerpo), 'restaura la copia');
  ok(!(await pedir(w, 'GET', '/panel', { query: { q: 'Zacarías' } })).cuerpo.includes('Zacarías Temporal'), 'tras restaurar, el paciente posterior a la copia ya no está');
  ok(!!(await w.Store.get('db_antes_de_restaurar')), 'se guarda una red de seguridad antes de restaurar');

  console.log('Sesión, ajustes y contraseña');
  r = await pedir(w, 'POST', '/panel/ajustes/institucion', { body: { csrf: token, institucion_nombre: 'Hospital Nuevo', correo: 'malo' } });
  ok(r.status === 400 && /correo no es válido/.test(r.cuerpo), 'valida correo en ajustes');
  r = await pedir(w, 'POST', '/panel/ajustes/institucion', { body: { csrf: token, institucion_nombre: 'Hospital Nuevo', correo: 'hola@hospital.org' } });
  ok(r.status === 302, 'guarda datos de la institución');
  ok(/Hospital Nuevo/.test((await pedir(w, 'GET', '/panel/ajustes')).cuerpo), 'el cambio se refleja en pantalla');
  r = await pedir(w, 'POST', '/panel/ajustes/clave', { body: { csrf: token, actual: 'incorrecta', nueva: 'otra-clave-123', nueva2: 'otra-clave-123' } });
  ok(r.status === 400 && /actual no es correcta/.test(r.cuerpo), 'cambio de clave exige la clave actual');
  r = await pedir(w, 'POST', '/panel/ajustes/clave', { body: { csrf: token, actual: 'clave-segura-1', nueva: 'otra-clave-123', nueva2: 'otra-clave-123' } });
  ok(r.status === 302, 'cambia la contraseña');

  r = await pedir(w, 'GET', '/logout'); ok(r.status === 302, 'cierra sesión');
  r = await pedir(w, 'GET', '/panel'); ok(r.status === 302 && r.headers.location === '/login', 'sin sesión, el panel redirige al login');
  const tokenLogin = csrfDe((await pedir(w, 'GET', '/login')).cuerpo);
  const t0 = Date.now();
  r = await pedir(w, 'POST', '/login', { body: { csrf: tokenLogin, usuario: 'admin01', clave: 'clave-segura-1' } });
  ok(r.status === 401 && Date.now() - t0 >= 900, 'la clave anterior ya no sirve (y hay retardo anti-fuerza-bruta)');
  r = await pedir(w, 'POST', '/login', { body: { csrf: tokenLogin, usuario: 'admin01', clave: 'otra-clave-123' } });
  ok(r.status === 302, 'entra con la nueva contraseña');

  console.log('Persistencia (reabrir la app)');
  const w2 = mundo();
  await w2.Store.set('db', await w.Store.get('db'));
  await w2.Store.set('config', await w.Store.get('config'));
  await w2.router.iniciar(shim);
  const t2 = csrfDe((await pedir(w2, 'GET', '/login')).cuerpo);
  r = await pedir(w2, 'POST', '/login', { body: { csrf: t2, usuario: 'admin01', clave: 'otra-clave-123' } });
  ok(r.status === 302, 'tras reiniciar, el usuario y la clave siguen vigentes');
  ok((await pedir(w2, 'GET', '/panel', { query: { q: 'Pérez' } })).cuerpo.includes('Ana Pérez'), 'tras reiniciar, los pacientes siguen guardados');

  console.log(`\n${n} comprobaciones correctas`);
})().catch((e) => { console.error('\n✘ FALLÓ:', e.message); process.exit(1); });
