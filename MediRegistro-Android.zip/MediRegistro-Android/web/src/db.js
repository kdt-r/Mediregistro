'use strict';
const Store = require('./store');

const ESQUEMA = `
CREATE TABLE IF NOT EXISTS pacientes_registro (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  folio TEXT NOT NULL UNIQUE,
  especialidad TEXT NOT NULL,
  nombres TEXT NOT NULL, apellidos TEXT NOT NULL,
  documento_tipo TEXT NOT NULL, documento_numero TEXT NOT NULL,
  fecha_nacimiento TEXT NOT NULL, sexo TEXT NOT NULL,
  telefono TEXT NOT NULL, correo TEXT, direccion TEXT NOT NULL,
  contacto_emergencia_nombre TEXT NOT NULL, contacto_emergencia_telefono TEXT NOT NULL,
  seguro_medico TEXT, tipo_sangre TEXT, alergias TEXT,
  datos_especificos TEXT,
  creado_en TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_documento ON pacientes_registro (documento_numero);
CREATE INDEX IF NOT EXISTS idx_especialidad ON pacientes_registro (especialidad);
`;

let SQL, db, tam = 0, cola = Promise.resolve();

// `modulo` es lo que devuelve initSqlJs() (sql.js compilado a WebAssembly)
async function abrir(modulo) {
  SQL = modulo;
  const guardado = await Store.get('db');
  cargar(guardado ? new Uint8Array(guardado) : null);
  await persistir();
}

function cargar(bytes) {
  db = new SQL.Database(bytes || undefined);
  db.run(ESQUEMA);
}

// Guarda una instantánea completa en IndexedDB (transacción atómica) y devuelve una promesa
function persistir() {
  const bytes = db.export();
  tam = bytes.length;
  const p = cola.catch(() => {}).then(() => Store.set('db', bytes));
  cola = p;
  return p;
}

function todos(sql, params = []) {
  const st = db.prepare(sql);
  try {
    st.bind(params);
    const filas = [];
    while (st.step()) filas.push(st.getAsObject());
    return filas;
  } finally { st.free(); }
}
const uno = (sql, params) => todos(sql, params)[0];

function ejecutar(sql, params = []) { db.run(sql, params); return persistir(); }

const hex = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (x) => x.toString(16).padStart(2, '0')).join('');

function generarFolio() {
  const f = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const fecha = `${f.getFullYear()}${p(f.getMonth() + 1)}${p(f.getDate())}`;
  for (let i = 0; i < 10; i++) {
    const folio = `REG-${fecha}-${hex(3).slice(0, 5).toUpperCase()}`;
    if (!uno('SELECT 1 AS x FROM pacientes_registro WHERE folio = ?', [folio])) return folio;
  }
  throw new Error('No se pudo generar un folio único');
}

function exportarBytes() { return db.export(); }
const tamano = () => tam;

// Restaura una copia de seguridad (valida que sea una base de MediRegistro)
async function restaurar(bytes) {
  let prueba;
  try { prueba = new SQL.Database(bytes); } catch (_) { throw new Error('El archivo no es una copia de seguridad de MediRegistro.'); }
  try {
    const r = prueba.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='pacientes_registro'");
    if (!r.length) throw new Error('El archivo no es una copia de seguridad de MediRegistro.');
  } catch (e) {
    if (/MediRegistro/.test(e.message)) throw e;
    throw new Error('El archivo no es una copia de seguridad de MediRegistro.');
  } finally { prueba.close(); }
  await Store.set('db_antes_de_restaurar', db.export()); // red de seguridad
  db.close();
  cargar(bytes);
  await persistir();
}

module.exports = { abrir, todos, uno, ejecutar, generarFolio, exportarBytes, restaurar, tamano };
