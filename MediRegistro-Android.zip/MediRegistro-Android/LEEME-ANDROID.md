# MediRegistro para Android

Versión Android de MediRegistro 1.2.0. Es la **misma aplicación** (mismas pantallas, formularios por especialidad, panel, Excel y copias de seguridad), pero en lugar de un servidor Node/Electron corre **dentro del teléfono**, sin internet y sin pedir ningún permiso.

## Cómo funciona

| Escritorio (Electron) | Android |
|---|---|
| Servidor Express en `127.0.0.1` | Un enrutador JavaScript dentro del WebView (`web/src/router.js`) |
| SQLite en `%APPDATA%` (sql.js) | El mismo sql.js; la base se guarda en IndexedDB, privada de la app |
| `config.json` + contraseñas scrypt | Configuración en IndexedDB + contraseñas PBKDF2-SHA256 |
| Descarga de archivos del navegador | Selector de Android: se guarda en Descargas, Drive, USB… |
| Imprimir con Electron | Diálogo de impresión de Android (permite "Guardar como PDF") |

`vistas.js` y `especialidades.js` son **idénticos** al original. `style.css` no se tocó; las adaptaciones para pantalla pequeña están en `web/public/movil.css`.

## Obtener el APK

### Opción A — sin instalar nada (GitHub)
1. Cree un repositorio en github.com y suba el contenido de esta carpeta.
2. Pestaña **Actions → Compilar APK de MediRegistro → Run workflow**.
3. Al terminar (unos 5 min), descargue **MediRegistro-APK** en la sección *Artifacts*. Dentro está `app-debug.apk`.

El flujo instala dependencias, ejecuta las pruebas y compila. Si una prueba falla, no genera APK.

### Opción B — en su computador (Node 22+, JDK 17, Android Studio)
```
npm install
npm test            # opcional: prueba la lógica
node build-web.js   # copia la app web a android/app/src/main/assets
```
Abra la carpeta `android/` con Android Studio → **Build → Build APK(s)**.
El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.
(Por línea de comandos: `gradle -p android assembleDebug` con Gradle 8.9.)

## Instalar en el teléfono
Copie `app-debug.apk` al teléfono y ábralo. Android pedirá permitir "instalar apps de origen desconocido" para el navegador o el gestor de archivos que use. La primera vez aparece el asistente para crear la institución y el usuario administrador, igual que en el programa de Windows.

## Cosas que conviene saber
- **Los datos viven solo en ese teléfono.** No hay sincronización entre dispositivos. Haga copias periódicas: *Ajustes → Descargar copia de seguridad* y guárdela en Drive o en el computador.
- Desinstalar la app, o *Borrar datos* en los ajustes de Android, **elimina todos los registros**.
- La copia de seguridad contiene los pacientes, **no** el usuario ni la contraseña (igual que en la versión de escritorio). Al restaurar en otro teléfono, primero complete el asistente y luego restaure.
- La sesión se cierra sola al cerrar la app; hay que volver a entrar con usuario y contraseña.
- Si la app maneja datos reales de pacientes, active la protección contra capturas de pantalla poniendo `BLOQUEAR_CAPTURAS = true` en `MainActivity.java`, y use bloqueo de pantalla en el teléfono.
- El APK generado es de *depuración* (firmado con clave de prueba): sirve para instalar directamente. Para publicar en Google Play hay que generar un APK/AAB de *release* con su propia clave y subir `targetSdk` al mínimo que Google exija en ese momento.
- "Abrir carpeta de datos" no existe en Android (la base es privada de la app); en su lugar use la copia de seguridad.

## Estructura
```
web/src/        router.js (antes server.js), db.js, config.js, store.js, boot.js (pegamento del WebView)
                vistas.js y especialidades.js (sin cambios)
web/public/     style.css, movil.css, fuentes
android/        proyecto Android (MainActivity.java: WebView, guardar/elegir archivos, imprimir, atrás)
build-web.js    empaqueta todo en android/app/src/main/assets
test/           pruebas (lógica con SQLite + recorrido completo en Chromium móvil)
.github/        compilación automática del APK
```
