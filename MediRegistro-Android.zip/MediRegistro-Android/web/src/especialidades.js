'use strict';
/**
 * Catálogo de especialidades. Para agregar una nueva, copie un bloque y ajuste
 * sus campos. Tipos de campo: select, text, number, date, textarea, checks.
 */
const SI = (d) => `<svg width="22" height="22" viewBox="0 0 24 24" fill="none">${d}</svg>`;

const motivo = (opciones) => ({ name: 'motivo_consulta', label: 'Motivo de la consulta', type: 'select', required: true, options: opciones });
const obs = { name: 'observaciones', label: 'Observaciones', hint: '(medicamentos u otros datos importantes)', type: 'textarea', full: true };

module.exports = [
  {
    slug: 'cardiologia', color: '#E5484D', nombre: 'Cardiología',
    desc: 'Presión arterial, antecedentes cardíacos y síntomas.',
    intro: 'Datos básicos del paciente y su motivo de consulta cardiológica.',
    icon: SI('<path d="M12 21s-7-4.6-9.5-9C.6 8.3 2.6 4 6.5 4c2 0 3.4 1.1 5.5 3.4C14.1 5.1 15.5 4 17.5 4 21.4 4 23.4 8.3 21.5 12 19 16.4 12 21 12 21Z" stroke="currentColor" stroke-width="1.6"/><path d="M4 12h4l2-4 3 8 2-5h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'),
    secciones: [{ titulo: 'Información cardiovascular', campos: [
      motivo(['Dolor en el pecho', 'Palpitaciones', 'Falta de aire', 'Hipertensión', 'Control post-infarto', 'Chequeo preventivo', 'Otro']),
      { name: 'presion_arterial', label: 'Presión arterial', hint: '(si la conoce)', type: 'text', placeholder: 'Ej. 130/85' },
      { name: 'antecedentes', label: 'Antecedentes', type: 'checks', full: true, options: ['Hipertensión', 'Infarto previo', 'Arritmia', 'Cirugía cardíaca', 'Colesterol alto', 'Diabetes'] },
      obs,
    ] }],
  },
  {
    slug: 'neurologia', color: '#7C5CFC', nombre: 'Neurología',
    desc: 'Cefaleas, convulsiones, mareos y antecedentes.',
    intro: 'Datos básicos del paciente y sus síntomas neurológicos.',
    icon: SI('<path d="M9 3a3 3 0 0 0-3 3v1a3 3 0 0 0-1 5.8V15a3 3 0 0 0 3 3h.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M15 3a3 3 0 0 1 3 3v1a3 3 0 0 1 1 5.8V15a3 3 0 0 1-3 3h-.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M9 20h6M11 18v3M13 18v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'),
    secciones: [{ titulo: 'Información neurológica', campos: [
      motivo(['Dolor de cabeza recurrente', 'Convulsiones', 'Mareos o vértigo', 'Pérdida de memoria', 'Hormigueo o adormecimiento', 'Temblores', 'Otro']),
      { name: 'frecuencia_sintomas', label: 'Frecuencia de los síntomas', type: 'select', options: ['Ocasional', 'Semanal', 'Diaria', 'Constante'] },
      { name: 'antecedentes', label: 'Antecedentes', type: 'checks', full: true, options: ['Migraña', 'Epilepsia', 'ACV previo', 'Traumatismo craneal', 'Cirugía cerebral'] },
      obs,
    ] }],
  },
  {
    slug: 'pediatria', color: '#F59E0B', nombre: 'Pediatría',
    desc: 'Datos del niño o niña, tutor, peso y talla.',
    intro: 'Datos del niño o niña y de su madre, padre o tutor responsable.',
    icon: SI('<circle cx="12" cy="7" r="3.2" stroke="currentColor" stroke-width="1.6"/><path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>'),
    secciones: [{ titulo: 'Información pediátrica', campos: [
      { name: 'tutor_nombre', label: 'Nombre del tutor', type: 'text', required: true },
      { name: 'tutor_parentesco', label: 'Parentesco', type: 'select', required: true, options: ['Madre', 'Padre', 'Abuelo/a', 'Tutor legal', 'Otro'] },
      motivo(['Control de niño sano', 'Fiebre', 'Tos o gripe', 'Vómito o diarrea', 'Erupción en la piel', 'Vacunación', 'Otro']),
      { name: 'peso', label: 'Peso (kg)', type: 'number', step: '0.1' },
      { name: 'talla', label: 'Talla (cm)', type: 'number', step: '0.1' },
      obs,
    ] }],
  },
  {
    slug: 'oncologia', color: '#D6409F', nombre: 'Oncología',
    desc: 'Tipo de cáncer, etapa y tratamientos.',
    intro: 'Datos básicos del paciente y su situación oncológica.',
    icon: SI('<circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.6"/><path d="M12 7.5v9M8 12h8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>'),
    secciones: [{ titulo: 'Información oncológica', campos: [
      motivo(['Diagnóstico reciente', 'Segunda opinión', 'Control de tratamiento', 'Seguimiento post-tratamiento', 'Síntomas nuevos']),
      { name: 'tipo_cancer', label: 'Tipo de cáncer', hint: '(si lo conoce)', type: 'text', placeholder: 'Ej. mama, colon' },
      { name: 'etapa', label: 'Etapa', hint: '(si la conoce)', type: 'select', options: [['', 'No lo sé / no aplica'], 'Etapa I', 'Etapa II', 'Etapa III', 'Etapa IV'] },
      { name: 'tratamientos', label: 'Tratamientos', type: 'checks', full: true, options: ['Quimioterapia', 'Radioterapia', 'Cirugía', 'Inmunoterapia', 'Ninguno aún'] },
      obs,
    ] }],
  },
  {
    slug: 'traumatologia', color: '#2F80ED', nombre: 'Traumatología',
    desc: 'Fracturas, lesiones deportivas y dolor.',
    intro: 'Datos básicos del paciente y su lesión.',
    icon: SI('<path d="M6 6l5 5-3 3 5 5 3-3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 4l6 6-3 3-6-6z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>'),
    secciones: [{ titulo: 'Información de la lesión', campos: [
      motivo(['Fractura sospechada', 'Esguince', 'Dolor articular', 'Lesión deportiva', 'Dolor de espalda', 'Control post-cirugía', 'Otro']),
      { name: 'zona_afectada', label: 'Zona afectada', type: 'text', required: true, placeholder: 'Ej. rodilla derecha' },
      { name: 'nivel_dolor', label: 'Nivel de dolor (0 a 10)', type: 'number', min: 0, max: 10 },
      obs,
    ] }],
  },
  {
    slug: 'endocrinologia', color: '#12A594', nombre: 'Endocrinología / Diabetes',
    desc: 'Glucosa, tipo de diabetes y tratamiento.',
    intro: 'Datos básicos del paciente y su control metabólico.',
    icon: SI('<path d="M12 3a4 4 0 0 1 4 4c0 2-2 3-2 5a2 2 0 1 1-4 0c0-2-2-3-2-5a4 4 0 0 1 4-4Z" stroke="currentColor" stroke-width="1.6"/><path d="M9 19h6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>'),
    secciones: [{ titulo: 'Información metabólica', campos: [
      motivo(['Diagnóstico reciente de diabetes', 'Control de diabetes', 'Problemas de tiroides', 'Control de peso / obesidad', 'Otro trastorno hormonal']),
      { name: 'tipo_diabetes', label: 'Tipo de diabetes', hint: '(si aplica)', type: 'select', options: ['No aplica', 'Tipo 1', 'Tipo 2', 'Gestacional', 'No lo sé'] },
      { name: 'glucosa_reciente', label: 'Glucosa reciente (mg/dL)', type: 'number' },
      { name: 'tratamiento', label: 'Tratamiento actual', type: 'checks', full: true, options: ['Insulina', 'Metformina u otro oral', 'Dieta y ejercicio', 'Ninguno aún'] },
      obs,
    ] }],
  },
];

/** Datos esenciales: solo lo indispensable, en TODOS los formularios (8 campos). */
module.exports.comunes = [
  { name: 'nombres', label: 'Nombres', type: 'text', required: true, auto: 'given-name' },
  { name: 'apellidos', label: 'Apellidos', type: 'text', required: true, auto: 'family-name' },
  { name: 'documento_numero', label: 'Documento de identidad', type: 'text', required: true },
  { name: 'fecha_nacimiento', label: 'Fecha de nacimiento', type: 'date', required: true },
  { name: 'sexo', label: 'Sexo', type: 'select', required: true, options: ['Femenino', 'Masculino', 'Otro'] },
  { name: 'telefono', label: 'Teléfono', type: 'tel', required: true, auto: 'tel' },
  { name: 'contacto_emergencia_nombre', label: 'Contacto de emergencia', hint: '(nombre y teléfono)', type: 'text', required: true, full: true, placeholder: 'Ej. Carlos Pérez · 5555-1234' },
  { name: 'alergias', label: 'Alergias conocidas', type: 'text', full: true, placeholder: "Escriba 'Ninguna' si no tiene" },
];
