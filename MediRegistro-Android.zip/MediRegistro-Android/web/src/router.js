'use strict';
const db = require('./db');
const config = require('./config');
const V = require('./vistas');
const ESP = require('./especialidades');

const POR_PAGINA = 50;
/* ---------- Validación de formularios ---------- */
const optVal = (o) => (Array.isArray(o) ? o[0] : o);
const texto = (v) => (typeof v === 'string' ? v.trim() : '');
const fechaOk = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(new Date(s).getTime());

function validar(esp, body) {
  const errores = [], datos = {}, especificos = {};
  const procesar = (f, destino) => {
    if (f.type === 'checks') {
      const validas = f.options.map(optVal);
      const marcadas = [].concat(body[f.name] || []).filter((x) => typeof x === 'string' && validas.includes(x));
      if (marcadas.length) destino[f.name] = marcadas;
      return;
    }
    const v = texto(body[f.name]).slice(0, f.type === 'textarea' ? 3000 : 300);
    if (v === '') {
      if (f.required) errores.push(`El campo "${f.label}" es obligatorio.`);
      destino[f.name] = '';
      return;
    }
    if (f.type === 'select' && !f.options.map(optVal).includes(v)) errores.push(`Valor no válido en "${f.label}".`);
    if (f.type === 'date' && !fechaOk(v)) errores.push(`La fecha de "${f.label}" no es válida.`);
    if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) errores.push('El correo electrónico no es válido.');
    if (f.type === 'number') {
      const n = Number(v);
      if (!Number.isFinite(n) || (f.min !== undefined && n < f.min) || (f.max !== undefined && n > f.max)) errores.push(`El valor de "${f.label}" no es válido.`);
    }
    destino[f.name] = v;
  };
  ESP.comunes.forEach((f) => procesar(f, datos));
  esp.secciones.forEach((s) => s.campos.forEach((f) => procesar(f, especificos)));
  if (datos.fecha_nacimiento && fechaOk(datos.fecha_nacimiento)) {
    const d = new Date(datos.fecha_nacimiento);
    if (d > new Date() || d.getFullYear() < 1900) errores.push('La fecha de nacimiento no es válida.');
  }
  return { errores, datos, especificos };
}

const fechaLocal = (d) => { const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
const ahora = () => { const f = new Date(), p = (n) => String(n).padStart(2, '0'); return `${fechaLocal(f)} ${p(f.getHours())}:${p(f.getMinutes())}:${p(f.getSeconds())}`; };

function csvSeguro(v) {
  const s = v == null ? '' : String(v);
  // Evita que Excel interprete el texto como fórmula; deja pasar teléfonos como +502 1234
  if (/^[=@\t\r]/.test(s) || (/^[+-]/.test(s) && !/^[+-][\d\s()-]+$/.test(s))) return "'" + s;
  return s;
}
const csvFila = (arr) => arr.map((v) => `"${csvSeguro(v).replace(/"/g, '""')}"`).join(',');

function estadisticas() {
  const hoy = new Date(), hoyStr = fechaLocal(hoy);
  const hace = (n) => { const d = new Date(hoy); d.setDate(d.getDate() - n); return d; };
  const cuenta = (where, params = []) => db.uno('SELECT COUNT(*) AS n FROM pacientes_registro WHERE ' + where, params).n;
  const porDia = {};
  db.todos('SELECT substr(creado_en,1,10) AS d, COUNT(*) AS n FROM pacientes_registro WHERE substr(creado_en,1,10) >= ? GROUP BY d', [fechaLocal(hace(6))]).forEach((r) => { porDia[r.d] = r.n; });
  const nombres = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  const dias = [];
  for (let i = 6; i >= 0; i--) { const d = hace(i), f = fechaLocal(d); dias.push({ n: porDia[f] || 0, etiqueta: i === 0 ? 'hoy' : `${nombres[d.getDay()]} ${d.getDate()}`, hoy: i === 0 }); }
  const conteos = {};
  db.todos('SELECT especialidad, COUNT(*) AS n FROM pacientes_registro GROUP BY especialidad').forEach((r) => { conteos[r.especialidad] = r.n; });
  const h = hoy.getHours();
  let respaldoDias = null;
  if (config.cfg('ultimo_respaldo')) respaldoDias = Math.floor((hoy - new Date(config.cfg('ultimo_respaldo').replace(' ', 'T'))) / 86400000);
  return {
    hoy: cuenta('substr(creado_en,1,10) = ?', [hoyStr]),
    semana: cuenta('substr(creado_en,1,10) >= ?', [fechaLocal(hace(6))]),
    mes: cuenta('substr(creado_en,1,7) = ?', [hoyStr.slice(0, 7)]),
    total: cuenta('1=1'),
    dias,
    porEsp: ESP.map((e) => ({ nombre: e.nombre, color: e.color, n: conteos[e.nombre] || 0 })),
    recientes: db.todos('SELECT * FROM pacientes_registro ORDER BY id DESC LIMIT 7'),
    saludo: h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches',
    fechaLarga: hoy.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }),
    respaldoDias,
  };
}

function consultaFiltros(q, especialidad, fecha) {
  let where = ' WHERE 1=1'; const params = [];
  if (fecha) { where += ' AND substr(creado_en,1,10) = ?'; params.push(fecha); }
  if (especialidad) { where += ' AND especialidad = ?'; params.push(especialidad); }
  if (q) { where += ' AND (nombres LIKE ? OR apellidos LIKE ? OR documento_numero LIKE ? OR folio LIKE ? OR (nombres || \' \' || apellidos) LIKE ?)'; const l = `%${q}%`; params.push(l, l, l, l, l); }
  return { where, params };
}

/* ---------- Mini enrutador (reemplaza a Express: todo corre dentro del teléfono) ---------- */
const aleatorio = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (x) => x.toString(16).padStart(2, '0')).join('');
const nuevaSesion = () => ({ csrf: aleatorio(16), admin: false, flash: '' });
let ses = nuevaSesion(); // una sola sesión: el teléfono lo usa una persona a la vez; se pierde al cerrar la app

class Respuesta {
  constructor(fin) { this.codigo = 200; this.cab = {}; this.fin = fin; this.listo = false; }
  status(c) { this.codigo = c; return this; }
  setHeader(k, v) { this.cab[k.toLowerCase()] = v; }
  send(cuerpo) { this.cerrar({ cuerpo }); }
  sendStatus(c) { this.codigo = c; this.cerrar({ cuerpo: '' }); }
  redirect(url) { this.codigo = 302; this.cab.location = url; this.cerrar({ cuerpo: '' }); }
  cerrar(extra) { if (this.listo) return; this.listo = true; this.fin({ status: this.codigo, headers: this.cab, ...extra }); }
}

const capas = [];
const usar = (fn) => capas.push({ fn });
const patron = (p) => { const claves = []; const re = new RegExp('^' + p.replace(/:([a-z]+)/g, (_, k) => { claves.push(k); return '([^/]+)'; }) + '/?$'); return { re, claves }; };
const metodo = (m) => (p, ...fns) => { const { re, claves } = patron(p); fns.forEach((fn) => capas.push({ m, re, claves, fn })); };
const get = metodo('GET');
const post = metodo('POST');

// req: { method, path, query, body, headers }  →  { status, headers, cuerpo }
function atender(req) {
  return new Promise((resolve) => {
    const res = new Respuesta(resolve);
    req.ses = ses; req.params = {}; req.headers = req.headers || {}; req.query = req.query || {}; req.body = req.body || {};
    let i = 0;
    const siguiente = () => {
      while (i < capas.length) {
        const c = capas[i++];
        if (c.m && c.m !== req.method) continue;
        if (c.re) {
          const m = c.re.exec(req.path);
          if (!m) continue;
          req.params = {};
          c.claves.forEach((k, j) => { req.params[k] = decodeURIComponent(m[j + 1]); });
        }
        Promise.resolve().then(() => c.fn(req, res, siguiente)).catch((e) => {
          console.error(e);
          res.status(500).send('Ocurrió un error interno. Intente de nuevo.');
        });
        return;
      }
    };
    siguiente();
  });
}

const admin = (req, res, next) => (req.ses.admin ? next() : res.redirect('/login'));

// CSRF en toda petición POST
usar((req, res, next) => {
  if (req.method !== 'POST') return next();
  const t = req.headers['x-csrf'] || (req.body && req.body.csrf);
  if (typeof t !== 'string' || !config.iguales(t, req.ses.csrf)) {
    return res.status(403).send('La sesión expiró. Regrese, recargue la página e intente de nuevo.');
  }
  next();
});

// Primera ejecución: asistente de configuración
usar((req, res, next) => {
  if (!config.instalado() && req.path !== '/instalar') return res.redirect('/instalar');
  next();
});

/* --- Instalación --- */
get('/instalar', (req, res) => (config.instalado() ? res.redirect('/') : res.send(V.instalar(req.ses))));
post('/instalar', async (req, res) => {
  if (config.instalado()) return res.redirect('/');
  const b = req.body, v = {};
  ['institucion_nombre', 'telefono_admision', 'telefono_urgencias', 'correo', 'direccion', 'admin_user'].forEach((k) => { v[k] = texto(b[k]).slice(0, 200); });
  const errores = [];
  if (!/^[A-Za-z0-9._-]{4,30}$/.test(v.admin_user)) errores.push('El usuario debe tener 4 a 30 caracteres (letras, números, punto o guion).');
  if (typeof b.admin_pass !== 'string' || b.admin_pass.length < 8) errores.push('La contraseña debe tener al menos 8 caracteres.');
  if (b.admin_pass !== b.admin_pass2) errores.push('Las contraseñas no coinciden.');
  if (v.correo && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.correo)) errores.push('El correo no es válido.');
  if (errores.length) return res.status(400).send(V.instalar(req.ses, { errores, v }));
  const { admin_user, ...resto } = v;
  await config.actualizar({ ...resto, admin_user, admin_hash: await config.hashClave(b.admin_pass), instalado_en: new Date().toISOString() });
  req.ses.admin = true;
  res.redirect('/');
});

/* --- Público --- */
get('/', (req, res) => res.send(req.ses.admin ? V.inicio(req.ses, estadisticas()) : V.nuevo(req.ses)));
get('/nuevo', (req, res) => res.send(V.nuevo(req.ses)));
get('/registro/:slug', (req, res, next) => {
  const esp = ESP.find((e) => e.slug === req.params.slug);
  return esp ? res.send(V.formulario(esp, req.ses)) : next();
});
post('/registro/:slug', async (req, res, next) => {
  const esp = ESP.find((e) => e.slug === req.params.slug);
  if (!esp) return next();
  const { errores, datos, especificos } = validar(esp, req.body);
  if (errores.length) return res.status(400).send(V.formulario(esp, req.ses, { errores, valores: req.body }));
  const folio = db.generarFolio();
  await db.ejecutar(
    `INSERT INTO pacientes_registro (folio, especialidad, nombres, apellidos, documento_tipo, documento_numero, fecha_nacimiento, sexo, telefono, correo, direccion, contacto_emergencia_nombre, contacto_emergencia_telefono, seguro_medico, tipo_sangre, alergias, datos_especificos, creado_en)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [folio, esp.nombre, datos.nombres, datos.apellidos, 'Documento', datos.documento_numero, datos.fecha_nacimiento, datos.sexo, datos.telefono, null, '', datos.contacto_emergencia_nombre, '', null, null, datos.alergias || null, JSON.stringify(especificos), ahora()]
  );
  res.redirect(`/gracias?folio=${encodeURIComponent(folio)}&esp=${encodeURIComponent(esp.nombre)}`);
});
get('/gracias', (req, res) => {
  const folio = String(req.query.folio || '');
  if (!/^REG-\d{8}-[A-F0-9]{5}$/.test(folio)) return res.redirect('/');
  const esp = ESP.find((e) => e.nombre === req.query.esp);
  res.send(V.gracias(folio, esp && esp.nombre, req.ses));
});

/* --- Acceso --- */
get('/login', (req, res) => (req.ses.admin ? res.redirect('/') : res.send(V.login(req.ses))));
post('/login', async (req, res) => {
  const u = texto(req.body.usuario), p = typeof req.body.clave === 'string' ? req.body.clave : '';
  const okClave = await config.claveValida(p, config.cfg('admin_hash'));
  if (okClave && u === config.cfg('admin_user')) { req.ses.admin = true; return res.redirect('/'); }
  await new Promise((r) => setTimeout(r, 1000)); // frena intentos repetidos
  res.status(401).send(V.login(req.ses, 'Usuario o contraseña incorrectos.'));
});
get('/logout', (req, res) => { ses = nuevaSesion(); res.redirect('/'); });

/* --- Panel del personal --- */
get('/panel', admin, (req, res) => {
  const q = texto(req.query.q), especialidad = texto(req.query.especialidad);
  const { where, params } = consultaFiltros(q, especialidad);
  const total = db.uno('SELECT COUNT(*) AS n FROM pacientes_registro' + where, params).n;
  const paginas = Math.max(1, Math.ceil(total / POR_PAGINA));
  const pagina = Math.min(paginas, Math.max(1, parseInt(req.query.pagina, 10) || 1));
  const filas = db.todos('SELECT * FROM pacientes_registro' + where + ' ORDER BY id DESC LIMIT ? OFFSET ?', [...params, POR_PAGINA, (pagina - 1) * POR_PAGINA]);
  const conteos = {};
  db.todos('SELECT especialidad, COUNT(*) AS n FROM pacientes_registro GROUP BY especialidad').forEach((r) => { conteos[r.especialidad] = r.n; });
  const totalGeneral = db.uno('SELECT COUNT(*) AS n FROM pacientes_registro').n;
  res.send(V.panel(req.ses, { filas, total, pagina, paginas, q, especialidad, conteos, totalGeneral }));
});
/* Registros del día (o de la fecha elegida) */
get('/hoy', admin, (req, res) => {
  const hoyStr = fechaLocal(new Date());
  let fecha = texto(req.query.fecha);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha) || fecha > hoyStr) fecha = hoyStr;
  const filas = db.todos('SELECT * FROM pacientes_registro WHERE substr(creado_en,1,10) = ? ORDER BY id DESC', [fecha]);
  const porEsp = ESP.map((e) => ({ nombre: e.nombre, color: e.color, n: filas.filter((r) => r.especialidad === e.nombre).length })).filter((e) => e.n);
  res.send(V.hoy(req.ses, { fecha, esHoy: fecha === hoyStr, filas, porEsp }));
});

/* Base de datos: todas las columnas, de un vistazo */
get('/panel/base', admin, (req, res) => {
  const q = texto(req.query.q), POR = 100;
  const { where, params } = consultaFiltros(q, '', '');
  const total = db.uno('SELECT COUNT(*) AS n FROM pacientes_registro' + where, params).n;
  const paginas = Math.max(1, Math.ceil(total / POR));
  const pagina = Math.min(paginas, Math.max(1, parseInt(req.query.pagina, 10) || 1));
  const filas = db.todos('SELECT * FROM pacientes_registro' + where + ' ORDER BY id DESC LIMIT ? OFFSET ?', [...params, POR, (pagina - 1) * POR]);
  res.send(V.base(req.ses, { filas, total, pagina, paginas, q, tam: db.tamano(), ruta: 'Memoria interna de la aplicación (privada)', puedeAbrir: false }));
});

get('/panel/registro/:id', admin, (req, res, next) => {
  const r = db.uno('SELECT * FROM pacientes_registro WHERE id = ?', [parseInt(req.params.id, 10) || 0]);
  return r ? res.send(V.ficha(req.ses, r)) : next();
});
get('/panel/exportar.csv', admin, (req, res) => {
  const f = texto(req.query.fecha);
  const { where, params } = consultaFiltros(texto(req.query.q), texto(req.query.especialidad), /^\d{4}-\d{2}-\d{2}$/.test(f) ? f : '');
  const filas = db.todos('SELECT * FROM pacientes_registro' + where + ' ORDER BY id DESC', params);
  const cab = ['Folio', 'Especialidad', 'Nombres', 'Apellidos', 'Tipo documento', 'Documento', 'Fecha nacimiento', 'Sexo', 'Teléfono', 'Correo', 'Dirección', 'Contacto emergencia', 'Tel. emergencia', 'Seguro', 'Tipo sangre', 'Alergias', 'Datos específicos', 'Fecha registro'];
  const lineas = [csvFila(cab)].concat(filas.map((r) => {
    let esp = {}; try { esp = JSON.parse(r.datos_especificos || '{}'); } catch (_) { /* vacío */ }
    const det = Object.entries(esp).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join('/') : v}`).join(' | ');
    return csvFila([r.folio, r.especialidad, r.nombres, r.apellidos, r.documento_tipo, r.documento_numero, r.fecha_nacimiento, r.sexo, r.telefono, r.correo, r.direccion, r.contacto_emergencia_nombre, r.contacto_emergencia_telefono, r.seguro_medico, r.tipo_sangre, r.alergias, det, r.creado_en]);
  }));
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="registros_${ahora().replace(/[: ]/g, '-')}.csv"`);
  res.send('\uFEFF' + lineas.join('\r\n'));
});

/* --- Ajustes y respaldos --- */
get('/panel/ajustes', admin, (req, res) => { const ok = req.ses.flash || ''; req.ses.flash = ''; res.send(V.ajustes(req.ses, { ok })); });
post('/panel/ajustes/institucion', admin, async (req, res) => {
  const cambios = {};
  ['institucion_nombre', 'telefono_admision', 'telefono_urgencias', 'correo', 'direccion'].forEach((k) => { cambios[k] = texto(req.body[k]).slice(0, 200); });
  if (cambios.correo && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cambios.correo)) return res.status(400).send(V.ajustes(req.ses, { errores: ['El correo no es válido.'] }));
  await config.actualizar(cambios);
  req.ses.flash = 'Datos de la institución guardados.';
  res.redirect('/panel/ajustes');
});
post('/panel/ajustes/clave', admin, async (req, res) => {
  const { actual, nueva, nueva2 } = req.body;
  const errores = [];
  if (!(await config.claveValida(String(actual || ''), config.cfg('admin_hash')))) errores.push('La contraseña actual no es correcta.');
  if (typeof nueva !== 'string' || nueva.length < 8) errores.push('La nueva contraseña debe tener al menos 8 caracteres.');
  if (nueva !== nueva2) errores.push('Las contraseñas nuevas no coinciden.');
  if (errores.length) return res.status(400).send(V.ajustes(req.ses, { errores }));
  await config.actualizar({ admin_hash: await config.hashClave(nueva) });
  req.ses.flash = 'Contraseña actualizada.';
  res.redirect('/panel/ajustes');
});
get('/panel/respaldo', admin, async (req, res) => {
  await config.actualizar({ ultimo_respaldo: ahora() });
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="copia-mediregistro-${ahora().slice(0, 10)}.sqlite"`);
  res.send(db.exportarBytes());
});
post('/panel/restaurar', admin, async (req, res) => {
  try {
    if (!(req.body instanceof Uint8Array) || !req.body.length) throw new Error('Archivo vacío.');
    await db.restaurar(req.body);
    res.send('Copia restaurada correctamente.');
  } catch (e) { res.status(400).send('No se pudo restaurar: ' + e.message); }
});

usar((req, res) => res.status(404).send(V.noEncontrado(req.ses)));

async function iniciar(modulosql) {
  await config.iniciar();
  await db.abrir(modulosql);
}

module.exports = { iniciar, atender };
