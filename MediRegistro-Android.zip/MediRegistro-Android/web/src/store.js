'use strict';
// Almacenamiento persistente clave/valor (IndexedDB dentro del WebView; memoria si no existe, p. ej. en pruebas)
const mem = new Map();
const hayIDB = typeof indexedDB !== 'undefined';
let dbp = null;

function abrir() {
  if (!dbp) {
    dbp = new Promise((ok, fallo) => {
      const r = indexedDB.open('mediregistro', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => ok(r.result);
      r.onerror = () => fallo(r.error);
    });
  }
  return dbp;
}

async function get(k) {
  if (!hayIDB) return mem.get(k);
  const d = await abrir();
  return new Promise((ok, fallo) => {
    const t = d.transaction('kv', 'readonly').objectStore('kv').get(k);
    t.onsuccess = () => ok(t.result);
    t.onerror = () => fallo(t.error);
  });
}

// Resuelve solo cuando la transacción terminó de escribirse (escritura durable)
async function set(k, v) {
  if (!hayIDB) { mem.set(k, v); return; }
  const d = await abrir();
  return new Promise((ok, fallo) => {
    const tx = d.transaction('kv', 'readwrite');
    tx.objectStore('kv').put(v, k);
    tx.oncomplete = () => ok();
    tx.onerror = () => fallo(tx.error);
    tx.onabort = () => fallo(tx.error);
  });
}

module.exports = { get, set };
