'use strict';
// Prueba de extremo a extremo en Chromium (viewport de teléfono). sql.js se sustituye por un adaptador que habla con SQLite del lado de Node.
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const { chromium } = require(process.env.PLAYWRIGHT_PATH || '/home/claude/.npm-global/lib/node_modules/playwright');
const { empaquetar } = require('../build-web.js');
const { Database } = require('./sqljs-shim.js');

const RAIZ = path.join(__dirname, '..');
const sitio = fs.mkdtempSync(path.join(os.tmpdir(), 'mr-'));
fs.writeFileSync(path.join(sitio, 'app.js'), empaquetar());
fs.copyFileSync(path.join(RAIZ, 'web', 'index.html'), path.join(sitio, 'index.html'));
const copiarDir = (d, h) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => { const o = path.join(d, e.name), t = path.join(h, e.name); if (e.isDirectory()) { fs.mkdirSync(t, { recursive: true }); copiarDir(o, t); } else fs.copyFileSync(o, t); });
copiarDir(path.join(RAIZ, 'web', 'public'), sitio);
fs.writeFileSync(path.join(sitio, 'sql-wasm.js'), `(function(){
 function rpc(op,d){var x=new XMLHttpRequest();x.open('POST','/__sql',false);x.send(JSON.stringify(Object.assign({op:op},d)));if(x.status!==200)throw new Error(x.responseText);return JSON.parse(x.responseText);}
 var b64=function(u){var s='';for(var i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
 var un=function(s){return Uint8Array.from(atob(s),function(c){return c.charCodeAt(0)})};
 function Db(bytes){this.id=rpc('new',{b:bytes?b64(bytes):null}).id}
 Db.prototype.run=function(sql,p){rpc('run',{id:this.id,sql:sql,p:p||[]})};
 Db.prototype.prepare=function(sql){var id=this.id;return{p:[],rows:null,i:0,bind:function(p){this.p=p||[];return true},step:function(){if(!this.rows)this.rows=rpc('all',{id:id,sql:sql,p:this.p}).rows;if(this.i<this.rows.length){this.i++;return true}return false},getAsObject:function(){return this.rows[this.i-1]},free:function(){}}};
 Db.prototype.exec=function(sql){return rpc('exec',{id:this.id,sql:sql}).r};
 Db.prototype.export=function(){return un(rpc('export',{id:this.id}).b)};
 Db.prototype.close=function(){rpc('close',{id:this.id})};
 window.initSqlJs=function(){return Promise.resolve({Database:Db})};
})();`);

const bases = new Map(); let sig = 1;
const servidor = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/__sql') {
    let t = ''; req.on('data', (c) => { t += c; }); req.on('end', () => {
      try {
        const q = JSON.parse(t); let out = {};
        if (q.op === 'new') { const id = sig++; bases.set(id, new Database(q.b ? new Uint8Array(Buffer.from(q.b, 'base64')) : undefined)); out = { id }; }
        else if (q.op === 'run') bases.get(q.id).run(q.sql, q.p);
        else if (q.op === 'all') { const s = bases.get(q.id).prepare(q.sql); s.bind(q.p); const rows = []; while (s.step()) rows.push(s.getAsObject()); out = { rows }; }
        else if (q.op === 'exec') out = { r: bases.get(q.id).exec(q.sql) };
        else if (q.op === 'export') out = { b: Buffer.from(bases.get(q.id).export()).toString('base64') };
        else if (q.op === 'close') { bases.get(q.id).close(); bases.delete(q.id); }
        res.end(JSON.stringify(out));
      } catch (e) { res.statusCode = 500; res.end(e.message); }
    });
    return;
  }
  const f = path.join(sitio, decodeURIComponent(req.url.split('?')[0]));
  if (!f.startsWith(sitio) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.statusCode = 404; return res.end('no'); }
  const tipos = { '.js': 'text/javascript', '.html': 'text/html', '.css': 'text/css', '.woff2': 'font/woff2' };
  res.setHeader('Content-Type', tipos[path.extname(f)] || 'application/octet-stream');
  res.end(fs.readFileSync(f));
});

let n = 0;
const ok = (c, m) => { assert.ok(c, m); n++; console.log('  ✔ ' + m); };

(async () => {
  await new Promise((r) => servidor.listen(0, '127.0.0.1', r));
  const base = `http://localhost:${servidor.address().port}`;
  const nav = await chromium.launch();
  const ctx = await nav.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, acceptDownloads: true });
  const errores = [];
  const abrir = async () => {
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errores.push('pageerror: ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error') errores.push('console: ' + m.text()); });
    p.on('dialog', (d) => { p.__dialogos.push(d.message()); d.accept(); });
    p.__dialogos = [];
    // Simula el puente nativo que inyecta MainActivity
    await p.addInitScript(() => { window.__llamadas = []; window.AndroidBridge = { saveFile: (n, m, b) => window.__llamadas.push({ tipo: 'guardar', n, m, b }), print: () => window.__llamadas.push({ tipo: 'imprimir' }) }; });
    await p.goto(base + '/index.html');
    return p;
  };
  const ruta = (p) => new URL(p.url()).pathname + new URL(p.url()).search;

  console.log('Primer arranque y asistente');
  let p = await abrir();
  await p.waitForSelector('input[name=admin_user]');
  ok(ruta(p) === '/instalar', 'la app arranca en el asistente de configuración (URL ' + ruta(p) + ')');
  await p.fill('[name=institucion_nombre]', 'Clínica Móvil');
  await p.fill('[name=admin_user]', 'admin01');
  await p.fill('[name=admin_pass]', 'clave-movil-1');
  await p.fill('[name=admin_pass2]', 'clave-movil-1');
  await p.screenshot({ path: '/tmp/m1-instalar.png' });
  await Promise.all([p.waitForSelector('a[href="/nuevo"]'), p.click('form button[type=submit]')]);
  ok(ruta(p) === '/' && /Clínica Móvil/.test(await p.content()), 'tras instalar, entra al inicio del administrador');
  await p.screenshot({ path: '/tmp/m2-inicio.png' });

  console.log('Registrar un paciente desde la interfaz');
  await p.click('a[href="/nuevo"] >> nth=0');
  await p.waitForSelector('a[href^="/registro/"]');
  ok(ruta(p) === '/nuevo', 'navega a "Nuevo registro" sin recargar la página');
  await p.click('a[href^="/registro/"] >> nth=0');
  await p.waitForSelector('#formReg');
  await p.evaluate(() => {
    document.querySelectorAll('#formReg [required]').forEach((e) => {
      if (e.tagName === 'SELECT') e.value = Array.from(e.options).find((o) => o.value).value;
      else if (e.type === 'date') e.value = '1990-05-17';
      else if (e.type === 'number') e.value = e.min || '1';
      else e.value = 'Prueba';
      e.dispatchEvent(new Event('input', { bubbles: true }));
    });
    document.querySelector('[name=nombres]').value = 'Luisa';
    document.querySelector('[name=apellidos]').value = 'Fernández';
  });
  ok(/¡Listo para guardar!/.test(await p.textContent('#progTxt')), 'el script de la página (barra de progreso) se ejecuta');
  await p.screenshot({ path: '/tmp/m3-formulario.png' });
  await p.click('#formReg button[type=submit]');
  await p.waitForURL(/\/gracias\?folio=REG-/);
  ok(/REG-\d{8}-[A-F0-9]{5}/.test(await p.textContent('body')), 'guarda y muestra el comprobante con folio');
  await p.goBack(); await p.waitForSelector('#formReg');
  ok(/^\/registro\//.test(ruta(p)), 'el botón "atrás" vuelve al formulario');
  await p.goForward(); await p.waitForURL(/\/gracias/);
  ok(true, 'el botón "adelante" funciona');

  console.log('Panel, ficha e impresión');
  await p.click('a[href="/panel"] >> nth=0'); await p.waitForSelector('tr.fila');
  ok(/Luisa Fernández/.test(await p.textContent('tr.fila')), 'el paciente aparece en "Todos los registros"');
  await p.fill('.search input[name=q]', 'Fernández'); await p.press('.search input[name=q]', 'Enter');
  await p.waitForFunction(() => location.search.includes('q='));
  ok(await p.locator('tr.fila').count() === 1, 'la búsqueda (formulario GET) filtra resultados');
  await p.click('tr.fila'); await p.waitForURL(/\/panel\/registro\/1/);
  ok(/Luisa/.test(await p.textContent('body')), 'tocar una fila abre la ficha (onclick adaptado)');
  await p.click('button:has-text("Imprimir")');
  ok((await p.evaluate(() => window.__llamadas)).some((l) => l.tipo === 'imprimir'), '"Imprimir" llama al puente nativo de impresión');

  console.log('Archivos: Excel, copia de seguridad y restauración');
  await p.goto(base + '/index.html'); // equivale a cerrar y reabrir la app: la sesión se pierde, los datos no
  await p.waitForSelector('a.nav-login, a[href="/login"]');
  await p.click('a[href="/login"] >> nth=0'); await p.waitForSelector('[name=clave]');
  await p.fill('[name=usuario]', 'admin01'); await p.fill('[name=clave]', 'clave-movil-1');
  await Promise.all([p.waitForSelector('a[href="/panel"]'), p.click('form button[type=submit]')]);
  ok(true, 'tras reabrir la app hay que volver a iniciar sesión, y la contraseña sigue vigente');
  await p.click('a[href="/panel"] >> nth=0'); await p.waitForSelector('tr.fila');
  ok(/Luisa Fernández/.test(await p.textContent('tr.fila')), 'los datos persisten en IndexedDB tras reabrir');
  await p.click('a[href^="/panel/exportar.csv"]');
  await p.waitForFunction(() => window.__llamadas.some((l) => l.tipo === 'guardar'));
  let g = (await p.evaluate(() => window.__llamadas)).find((l) => l.tipo === 'guardar');
  const csv = Buffer.from(g.b, 'base64').toString('utf8');
  ok(/^registros_.*\.csv$/.test(g.n) && g.m === 'text/csv' && csv.startsWith('\uFEFF"Folio"') && csv.includes('Luisa'), 'Excel: entrega el CSV al puente nativo con nombre y tipo correctos');
  await p.click('a[href="/panel/ajustes"] >> nth=0'); await p.waitForSelector('#archivo');
  await p.click('a[href="/panel/respaldo"]');
  await p.waitForFunction(() => window.__llamadas.filter((l) => l.tipo === 'guardar').length === 2);
  g = (await p.evaluate(() => window.__llamadas)).filter((l) => l.tipo === 'guardar')[1];
  ok(/^copia-mediregistro-.*\.sqlite$/.test(g.n) && Buffer.from(g.b, 'base64').length > 100, 'copia de seguridad: entrega el archivo .sqlite al puente nativo');
  const archivoCopia = path.join(sitio, g.n); fs.writeFileSync(archivoCopia, Buffer.from(g.b, 'base64'));
  await p.setInputFiles('#archivo', archivoCopia);
  p.__dialogos.length = 0;
  await p.click('button:has-text("Restaurar copia")');
  await p.waitForURL(/\/panel$/);
  ok(p.__dialogos.some((d) => /reemplazarán/.test(d)) && p.__dialogos.some((d) => /restaurada correctamente/.test(d)), 'restaurar: confirmación y aviso de éxito (fetch interceptado)');
  await p.waitForSelector('tr.fila');
  ok(/Luisa Fernández/.test(await p.textContent('tr.fila')), 'tras restaurar vuelve al panel con los datos');

  console.log('Captura de pantallas móviles');
  await p.screenshot({ path: '/tmp/m4-panel.png' });
  ok(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'el panel no desborda horizontalmente en 390 px');

  ok(errores.length === 0, 'sin errores de JavaScript en consola' + (errores.length ? ': ' + errores.join(' | ') : ''));
  await nav.close(); servidor.close();
  console.log(`\n${n} comprobaciones correctas en Chromium móvil`);
})().catch((e) => { console.error('\n✘ FALLÓ:', e.message.split('\n').slice(0, 6).join('\n')); process.exit(1); });
