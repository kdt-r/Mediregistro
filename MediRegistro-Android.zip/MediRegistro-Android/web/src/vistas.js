'use strict';
const { APP_NAME, APP_VERSION, cfg } = require('./config');
const ESP = require('./especialidades');

const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const opt = (o) => (Array.isArray(o) ? { v: o[0], l: o[1] } : { v: o, l: o });
const hoyISO = () => { const f = new Date(), p = (n) => String(n).padStart(2, '0'); return `${f.getFullYear()}-${p(f.getMonth() + 1)}-${p(f.getDate())}`; };

/* ---------- Iconos ---------- */
const P = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  userplus: '<path d="M15 20v-1.5a4.5 4.5 0 0 0-4.5-4.5h-3A4.5 4.5 0 0 0 3 18.5V20"/><circle cx="9" cy="7" r="3.5"/><path d="M19 8v6M16 11h6"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
  sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
  login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5M15 12H3"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  printer: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="9" rx="2"/><path d="M7 14h10v7H7z"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 20h16"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20v-1a5.5 5.5 0 0 1 5.5-5.5h2A5.5 5.5 0 0 1 15.5 19v1"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20v-1a5.5 5.5 0 0 0-3.5-5.1"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5L15.5 10"/>',
  pulse: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  wifioff: '<path d="M2 8.8a15 15 0 0 1 4-2.3M22 8.8a15 15 0 0 0-8.5-3.7M5 12.9a10 10 0 0 1 3-1.8M19 12.9a10 10 0 0 0-4-2.3M8.5 16.4a5 5 0 0 1 7 0M12 20h.01M3 3l18 18"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  today: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M9 15l2 2 4-4"/>',
};
const ico = (n, s = 20) => `<svg class="ico" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]}</svg>`;
const MARCA = '<svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M12 2 L21 7 V13 C21 18 17 21.5 12 23 C7 21.5 3 18 3 13 V7 Z" fill="#E6F4F1" stroke="currentColor" stroke-width="1.4"/><path d="M12 8v8M8 12h8" stroke="#FF6B57" stroke-width="2.4" stroke-linecap="round"/></svg>';

const colorDe = (nombre) => (ESP.find((e) => e.nombre === nombre) || {}).color || '#0B6E66';
const iniciales = (n, a) => (((n || '').trim()[0] || '') + ((a || '').trim()[0] || '')).toUpperCase() || '?';

/* ---------- Estructura: barra lateral + barra de herramientas ---------- */
function contarHoy() {
  try { return require('./db').uno('SELECT COUNT(*) AS n FROM pacientes_registro WHERE substr(creado_en,1,10) = ?', [hoyISO()]).n; } catch (_) { return 0; }
}

function layout({ titulo, cuerpo, ses, activo = '' }) {
  const admin = ses && ses.admin;
  const inst = cfg('institucion_nombre'), urg = cfg('telefono_urgencias');
  const hoyN = admin ? contarHoy() : 0;
  const item = (href, key, icon, label, color, badge) => `<a class="nav-item${activo === key ? ' activo' : ''}" style="--c:${color}" href="${href}"><span class="nav-ico">${ico(icon, 20)}</span><span class="nav-txt">${label}</span>${badge ? `<em class="nav-badge">${badge}</em>` : ''}</a>`;
  const menu = admin
    ? item('/', 'inicio', 'home', 'Inicio', '#12A594') + item('/nuevo', 'nuevo', 'userplus', 'Nuevo registro', '#FF6B57') + item('/hoy', 'hoy', 'today', 'Registros de hoy', '#F59E0B', hoyN || '') + item('/panel', 'registros', 'list', 'Todos los registros', '#2F80ED') + item('/panel/base', 'base', 'database', 'Base de datos', '#7C5CFC') + item('/panel/ajustes', 'ajustes', 'sliders', 'Ajustes', '#D6409F')
    : item('/', 'nuevo', 'userplus', 'Nuevo registro', '#FF6B57');
  const usuario = cfg('admin_user');
  const pie = admin
    ? `<div class="user-chip"><span class="avatar">${esc((usuario[0] || 'A').toUpperCase())}</span><div><b>${esc(usuario)}</b><small>Administrador</small></div><a class="icon-btn" href="/logout" title="Cerrar sesión">${ico('logout', 19)}</a></div>`
    : `<a class="nav-login" href="/login">${ico('lock', 19)}<span>Acceso del personal</span></a>`;
  const barra = admin
    ? `<div class="toolbar no-print"><form class="tb-search" action="/panel" method="get">${ico('search', 20)}<input type="search" name="q" placeholder="Buscar paciente, documento o folio…" aria-label="Buscar"></form>
<a class="tb-chip" href="/hoy">${ico('today', 19)}<span><b>${hoyN}</b> hoy</span></a><a class="tb-btn" href="/nuevo">${ico('userplus', 20)} Nuevo registro</a></div>` : '';
  return `<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(titulo)} — ${esc(APP_NAME)}</title><link rel="stylesheet" href="/style.css"></head>
<body><div class="shell">
<aside class="sidebar">
  <a class="logo" href="/"><span class="logo-mark">${MARCA}</span><span><b>${esc(APP_NAME)}</b>${inst ? `<small>${esc(inst)}</small>` : '<small>Admisión de pacientes</small>'}</span></a>
  <nav class="menu">${menu}</nav>
  <div class="side-foot">
    ${urg ? `<a class="urg" href="tel:${esc(urg.replace(/[^0-9+]/g, ''))}">${ico('phone', 22)}<span>Urgencias<br><b>${esc(urg)}</b></span></a>` : ''}
    ${pie}
    <div class="ver">v${esc(APP_VERSION)}</div>
  </div>
</aside>
<main class="main">${barra}<div class="wrap">${cuerpo}</div></main>
</div></body></html>`;
}

const encabezado = ({ titulo, sub, acciones = '', volver }) => `<header class="page-head">${volver ? `<a class="volver" href="${volver[0]}">${ico('back', 16)} ${esc(volver[1])}</a>` : ''}<div class="ph-row"><div><h1>${esc(titulo)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div><div class="ph-actions">${acciones}</div></div></header>`;
const alerta = (errores) => (errores && errores.length ? `<div class="alert alert-error">${ico('alert', 20)}<div><strong>Revise lo siguiente:</strong><ul>${errores.map((e) => `<li>${esc(e)}</li>`).join('')}</ul></div></div>` : '');
const aviso = (m) => (m ? `<div class="alert alert-ok">${ico('check', 20)}<div>${esc(m)}</div></div>` : '');

/* ---------- Fechas ---------- */
const edad = (f) => { const n = new Date(f), h = new Date(); let a = h.getFullYear() - n.getFullYear(); const m = h.getMonth() - n.getMonth(); if (m < 0 || (m === 0 && h.getDate() < n.getDate())) a--; return Number.isNaN(a) ? '' : a; };
function relativo(s) {
  const [d, t = ''] = String(s).split(' '); const hora = t.slice(0, 5);
  if (d === hoyISO()) return `Hoy ${hora}`;
  const ayer = new Date(); ayer.setDate(ayer.getDate() - 1);
  const p = (n) => String(n).padStart(2, '0');
  if (d === `${ayer.getFullYear()}-${p(ayer.getMonth() + 1)}-${p(ayer.getDate())}`) return `Ayer ${hora}`;
  const [y, m, dd] = d.split('-'); return `${dd}/${m}/${y}`;
}
const fechaHora = (s) => { const [d, t = ''] = String(s).split(' '); const [y, m, dd] = d.split('-'); return `${dd}/${m}/${y} ${t.slice(0, 5)}`; };

/* ---------- Campos de formulario ---------- */
function campo(f, val) {
  const v = val[f.name];
  const cls = 'field' + (f.full ? ' full' : '');
  const req = f.required ? ' <span class="req">*</span>' : '';
  const hint = f.hint ? ` <span class="hint">${esc(f.hint)}</span>` : '';
  const edadTag = f.name === 'fecha_nacimiento' ? '<span class="edad" id="edadCalc"></span>' : '';
  const label = `<label for="${f.name}">${esc(f.label)}${req}${hint}${edadTag}</label>`;
  if (f.type === 'checks') {
    const sel = [].concat(v || []);
    return `<div class="${cls}"><span class="lbl">${esc(f.label)} <span class="hint">(marque todas las que apliquen)</span></span><div class="chips">${f.options.map((o) => { const { v: ov, l } = opt(o); return `<label class="chip-opt"><input type="checkbox" name="${f.name}" value="${esc(ov)}"${sel.includes(ov) ? ' checked' : ''}>${esc(l)}</label>`; }).join('')}</div></div>`;
  }
  if (f.type === 'select') {
    const vacio = f.required || f.blank ? `<option value="">${esc(f.blankLabel || 'Seleccione…')}</option>` : '';
    return `<div class="${cls}">${label}<select id="${f.name}" name="${f.name}"${f.required ? ' required' : ''}>${vacio}${f.options.map((o) => { const { v: ov, l } = opt(o); return `<option value="${esc(ov)}"${v === ov ? ' selected' : ''}>${esc(l)}</option>`; }).join('')}</select></div>`;
  }
  if (f.type === 'textarea') {
    return `<div class="${cls}">${label}<textarea id="${f.name}" name="${f.name}" rows="3" maxlength="3000"${f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : ''}>${esc(v)}</textarea></div>`;
  }
  const attrs = [f.required && 'required', f.placeholder && `placeholder="${esc(f.placeholder)}"`, f.min !== undefined && `min="${f.min}"`, f.max !== undefined && `max="${f.max}"`, f.step && `step="${f.step}"`, f.auto && `autocomplete="${f.auto}"`, f.name === 'fecha_nacimiento' && `max="${hoyISO()}"`, f.type !== 'date' && 'maxlength="300"'].filter(Boolean).join(' ');
  return `<div class="${cls}">${label}<input type="${f.type}" id="${f.name}" name="${f.name}" value="${esc(v)}" ${attrs}></div>`;
}
const seccion = (n, titulo, campos, val) => `<section class="sec"><div class="sec-head"><span class="num">${n}</span><h2>${esc(titulo)}</h2></div><div class="grid">${campos.map((f) => campo(f, val)).join('')}</div></section>`;

/* ---------- Elegir especialidad ---------- */
function nuevo(ses) {
  const tarjetas = ESP.map((e) => `<a class="esp-card" style="--c:${e.color}" href="/registro/${e.slug}"><span class="esp-tile">${e.icon}</span><h3>${esc(e.nombre)}</h3><p>${esc(e.desc)}</p><span class="go">Abrir formulario ${ico('arrow', 18)}</span></a>`).join('');
  const cuerpo = `${encabezado({ titulo: 'Nuevo registro de paciente', sub: 'Elija la especialidad para abrir el formulario correspondiente.' })}
<div class="esp-grid">${tarjetas}</div>
<div class="tips"><span>${ico('file', 19)} Documento de identidad del paciente</span><span>${ico('phone', 19)} Teléfono y contacto de emergencia</span><span>${ico('alert', 19)} Alergias conocidas del paciente</span><span>${ico('clock', 19)} Toma menos de 2 minutos</span></div>`;
  return layout({ titulo: 'Nuevo registro', cuerpo, ses, activo: 'nuevo' });
}

function formulario(esp, ses, { errores = [], valores = {} } = {}) {
  let n = 1;
  const cuerpo = `<div style="--c:${esp.color}">
<a class="volver" href="/nuevo">${ico('back', 16)} Cambiar de especialidad</a>
<div class="hero-form"><span class="tile">${esp.icon}</span><div><h1>${esc(esp.nombre)}</h1><p>${esc(esp.intro)}</p></div></div>
${errores.length ? `<div style="margin-top:18px">${alerta(errores)}</div>` : ''}
<form id="formReg" method="post" action="/registro/${esp.slug}">
<input type="hidden" name="csrf" value="${esc(ses.csrf)}">
${seccion(n++, 'Datos esenciales del paciente', ESP.comunes, valores)}
${esp.secciones.map((s) => seccion(n++, s.titulo, s.campos, valores)).join('')}
<div class="actionbar">
  <div class="prog"><small id="progTxt">0 campos obligatorios</small><div class="prog-track"><div class="prog-bar" id="progBar"></div></div></div>
  <a class="btn btn-ghost" href="/nuevo">Cancelar</a>
  <button type="submit" class="btn btn-primary btn-lg">${ico('check', 20)} Guardar registro</button>
</div>
</form></div>
<script>
(function(){
  var f=document.getElementById('formReg'), req=[].slice.call(f.querySelectorAll('[required]'));
  var bar=document.getElementById('progBar'), txt=document.getElementById('progTxt');
  function upd(){ var ok=req.filter(function(e){return e.value.trim()!=='';}).length, p=req.length?Math.round(ok*100/req.length):100;
    bar.style.width=p+'%'; txt.textContent= ok===req.length ? '¡Listo para guardar!' : ok+' de '+req.length+' campos obligatorios completados'; }
  f.addEventListener('input',upd); f.addEventListener('change',upd); upd();
  var fn=document.getElementById('fecha_nacimiento'), out=document.getElementById('edadCalc');
  function edad(){ if(!fn.value){out.textContent='';return;} var n=new Date(fn.value),h=new Date(),a=h.getFullYear()-n.getFullYear(),m=h.getMonth()-n.getMonth();
    if(m<0||(m===0&&h.getDate()<n.getDate()))a--; out.textContent=a>=0?(a===1?'1 año':a+' años'):''; }
  if(fn&&out){fn.addEventListener('change',edad);edad();}
  var p=f.querySelector('[name=nombres]'); if(p&&!p.value)p.focus();
})();
</script>`;
  return layout({ titulo: 'Registro de ' + esp.nombre, cuerpo, ses, activo: 'nuevo' });
}

function gracias(folio, espNombre, ses) {
  const cuerpo = `<div class="ok-wrap"><div class="ok-badge">${ico('check', 46)}</div>
<h1>¡Registro guardado!</h1>
<p>El registro de <strong>${esc(espNombre || 'la especialidad')}</strong> quedó almacenado correctamente.<br>Entregue este folio al paciente para su admisión.</p>
<div class="folio-box"><small>Folio del registro</small><b id="folio">${esc(folio)}</b></div>
<div class="ok-actions no-print">
  <button class="btn btn-ghost" onclick="navigator.clipboard.writeText(document.getElementById('folio').textContent);this.textContent='¡Copiado!'">${ico('copy', 18)} Copiar folio</button>
  <button class="btn btn-ghost" onclick="window.print()">${ico('printer', 18)} Imprimir comprobante</button>
  <a class="btn btn-primary" href="/nuevo">${ico('userplus', 18)} Registrar otro paciente</a>
  ${ses.admin ? `<a class="btn btn-ghost" href="/panel?q=${encodeURIComponent(folio)}">${ico('search', 18)} Ver en registros</a>` : ''}
</div></div>`;
  return layout({ titulo: 'Registro confirmado', cuerpo, ses, activo: 'nuevo' });
}

/* ---------- Inicio (panel con estadísticas) ---------- */
function inicio(ses, s) {
  const max = Math.max(1, ...s.dias.map((d) => d.n));
  const maxE = Math.max(1, ...s.porEsp.map((e) => e.n));
  const kpi = (icon, color, n, label, href) => `<${href ? 'a href="' + href + '"' : 'div'} class="kpi" style="--c:${color}"><span class="kpi-ico">${ico(icon, 26)}</span><div><b>${n}</b><span>${label}</span></div></${href ? 'a' : 'div'}>`;
  const avisoRespaldo = s.total > 0 && (s.respaldoDias === null || s.respaldoDias >= 7)
    ? `<div class="alert alert-warn" style="margin-top:20px">${ico('shield', 22)}<div style="flex:1"><strong>${s.respaldoDias === null ? 'Aún no ha hecho una copia de seguridad.' : `La última copia de seguridad fue hace ${s.respaldoDias} días.`}</strong><br>Guarde una copia de los registros en una memoria USB o en la nube para no perder información.</div><a class="btn btn-ghost" href="/panel/ajustes#respaldo">Hacer copia ahora</a></div>` : '';
  const pasos = `<div class="card" style="margin-top:20px"><h2>${ico('check', 22)} Primeros pasos</h2><ul class="pasos">
    <li><a href="/panel/ajustes"><span class="n">1</span>Complete los datos de su institución (nombre y teléfonos)</a></li>
    <li><a href="/nuevo"><span class="n">2</span>Haga un registro de prueba para conocer los formularios</a></li>
    <li><a href="/panel/ajustes#respaldo"><span class="n">3</span>Descargue su primera copia de seguridad</a></li></ul></div>`;
  const recientes = s.recientes.length
    ? s.recientes.map((r) => `<a class="reciente" style="--c:${colorDe(r.especialidad)}" href="/panel/registro/${r.id}"><span class="avatar">${esc(iniciales(r.nombres, r.apellidos))}</span><div><b>${esc(r.nombres + ' ' + r.apellidos)}</b><small>${esc(r.especialidad)} · ${esc(relativo(r.creado_en))}</small></div>${ico('arrow', 18)}</a>`).join('')
    : `<div class="vacio">Todavía no hay registros.<br>Cuando guarde el primero aparecerá aquí.</div>`;
  const cuerpo = `<section class="banner">
  <svg class="ecg" viewBox="0 0 700 150" preserveAspectRatio="none" aria-hidden="true"><path d="M0 85 H180 L210 30 L250 135 L285 55 L310 85 H430 L455 60 L480 110 L505 85 H700"/></svg>
  <div class="fecha">${esc(s.fechaLarga)}</div>
  <h1>${esc(s.saludo)}${cfg('institucion_nombre') ? ', ' + esc(cfg('institucion_nombre')) : ''}</h1>
  <p>${s.hoy ? `Hoy se han registrado <strong>${s.hoy}</strong> paciente${s.hoy === 1 ? '' : 's'}.` : 'Aún no hay registros hoy. ¡Que tenga un excelente turno!'}</p>
  <div class="acciones"><a class="btn btn-white btn-lg" href="/nuevo">${ico('userplus', 22)} Nuevo registro</a><a class="btn btn-line btn-lg" href="/hoy">${ico('today', 22)} Registros de hoy</a></div>
</section>
<div class="kpis">${kpi('calendar', '#0B6E66', s.hoy, 'Registros de hoy', '/hoy')}${kpi('chart', '#2F80ED', s.semana, 'Últimos 7 días')}${kpi('pulse', '#D6409F', s.mes, 'Este mes')}${kpi('users', '#F59E0B', s.total, 'Total de pacientes', '/panel')}</div>
${avisoRespaldo}${s.total === 0 ? pasos : ''}
<div class="cols">
  <div class="card"><h2>${ico('chart', 22)} Registros por día</h2>
    <div class="dias">${s.dias.map((d) => `<div class="dia${d.hoy ? ' hoy' : ''}"><b>${d.n}</b><div class="col" style="height:${Math.round((d.n / max) * 100)}%"></div><span>${esc(d.etiqueta)}</span></div>`).join('')}</div></div>
  <div class="card"><h2>${ico('users', 22)} Por especialidad</h2>
    ${s.porEsp.map((e) => `<div class="barra${e.n ? '' : ' cero'}" style="--c:${e.color}"><span>${esc(e.nombre)}</span><div class="pista"><div class="rel" style="width:${Math.round((e.n / maxE) * 100)}%"></div></div><b>${e.n}</b></div>`).join('')}</div>
</div>
<div class="card" style="margin-top:20px"><h2>${ico('clock', 22)} Últimos registros</h2>${recientes}</div>`;
  return layout({ titulo: 'Inicio', cuerpo, ses, activo: 'inicio' });
}

/* ---------- Acceso e instalación ---------- */
function authLayout(titulo, ses, formulario) {
  return `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${esc(titulo)} — ${esc(APP_NAME)}</title><link rel="stylesheet" href="/style.css"></head>
<body><div class="auth">
<section class="auth-brand"><span class="logo-mark">${MARCA}</span><h1>${esc(APP_NAME)}</h1><p>Admisión y registro de pacientes, simple y rápido, para cualquier hospital o clínica.</p>
<ul><li>${ico('wifioff', 22)} Funciona sin conexión a internet</li><li>${ico('lock', 22)} Los datos se guardan solo en este equipo</li><li>${ico('file', 22)} Folio digital en cada registro</li></ul></section>
<section class="auth-form"><div class="auth-box">${formulario}</div></section></div></body></html>`;
}

function instalar(ses, { errores = [], v = {} } = {}) {
  const c = (n, l, t = 'text') => `<div class="field"><label for="${n}">${l}</label><input type="${t}" id="${n}" name="${n}" value="${esc(v[n])}"></div>`;
  return authLayout('Configuración inicial', ses, `<h2>Bienvenido</h2><p>Configure su programa en un minuto. Solo se hace una vez.</p>${alerta(errores)}
<form class="card" method="post" autocomplete="off"><input type="hidden" name="csrf" value="${esc(ses.csrf)}">
<div class="sub-t" style="margin-top:0">${ico('home', 20)} Su institución <span class="hint">(opcional)</span></div>
<div class="grid"><div class="field full"><label for="institucion_nombre">Nombre del hospital o clínica</label><input type="text" id="institucion_nombre" name="institucion_nombre" value="${esc(v.institucion_nombre)}" autofocus></div>
${c('telefono_admision', 'Teléfono de admisión', 'tel')}${c('telefono_urgencias', 'Teléfono de urgencias', 'tel')}${c('correo', 'Correo de contacto', 'email')}${c('direccion', 'Dirección')}</div>
<div class="sub-t">${ico('lock', 20)} Cuenta de administrador</div>
<div class="grid"><div class="field full"><label for="admin_user">Usuario <span class="req">*</span></label><input type="text" id="admin_user" name="admin_user" required value="${esc(v.admin_user)}"></div>
<div class="field"><label for="admin_pass">Contraseña <span class="req">*</span> <span class="hint">(mín. 8)</span></label><input type="password" id="admin_pass" name="admin_pass" required minlength="8"></div>
<div class="field"><label for="admin_pass2">Repetir contraseña <span class="req">*</span></label><input type="password" id="admin_pass2" name="admin_pass2" required minlength="8"></div></div>
<div class="acciones-fila"><button class="btn btn-primary btn-lg" type="submit">Comenzar ${ico('arrow', 20)}</button></div></form>`);
}

function login(ses, error) {
  return authLayout('Acceso', ses, `<h2>Acceso del personal</h2><p>Ingrese para ver los registros y las estadísticas.</p>${error ? `<div class="alert alert-error">${ico('alert', 20)}<div>${esc(error)}</div></div>` : ''}
<form class="card" method="post"><input type="hidden" name="csrf" value="${esc(ses.csrf)}"><div class="grid" style="grid-template-columns:1fr">
<div class="field"><label for="usuario">Usuario</label><input type="text" id="usuario" name="usuario" required autofocus></div>
<div class="field"><label for="clave">Contraseña</label><input type="password" id="clave" name="clave" required></div></div>
<div class="acciones-fila" style="justify-content:space-between"><a class="btn btn-ghost" href="/">${ico('back', 18)} Volver</a><button class="btn btn-primary btn-lg" type="submit">Entrar</button></div></form>`);
}

/* ---------- Registros ---------- */
function panel(ses, { filas, total, pagina, paginas, q, especialidad, conteos, totalGeneral }) {
  const href = (p) => '/panel?' + new URLSearchParams({ q, especialidad, pagina: p }).toString();
  const exportar = '/panel/exportar.csv?' + new URLSearchParams({ q, especialidad }).toString();
  const chip = (nombre, color, n, on) => `<a class="filtro${on ? ' on' : ''}" style="--c:${color}" href="/panel?${new URLSearchParams({ q, especialidad: nombre }).toString()}"><i></i>${esc(nombre || 'Todas')}<em>${n}</em></a>`;
  const filtros = chip('', '#0B6E66', totalGeneral, !especialidad) + ESP.map((e) => chip(e.nombre, e.color, conteos[e.nombre] || 0, especialidad === e.nombre)).join('');
  const cuerpo = `${encabezado({ titulo: 'Registros', sub: `${total} paciente${total === 1 ? '' : 's'} ${q || especialidad ? 'encontrado' + (total === 1 ? '' : 's') : 'registrado' + (total === 1 ? '' : 's')}`,
    acciones: `<a class="btn btn-ghost" href="${esc(exportar)}">${ico('download', 19)} Exportar a Excel</a><a class="btn btn-primary" href="/nuevo">${ico('userplus', 19)} Nuevo registro</a>` })}
<form class="search" method="get" action="/panel">${ico('search', 22)}<input type="search" name="q" value="${esc(q)}" placeholder="Buscar por nombre, documento o folio…" autofocus>${especialidad ? `<input type="hidden" name="especialidad" value="${esc(especialidad)}">` : ''}</form>
<div class="filtros">${filtros}</div>
${filas.length ? `<div class="tabla-card"><div class="table-wrap"><table class="reg"><thead><tr><th>Paciente</th><th>Especialidad</th><th>Documento</th><th>Teléfono</th><th>Registrado</th><th>Folio</th></tr></thead><tbody>
${filas.map((r) => `<tr class="fila" style="--c:${colorDe(r.especialidad)}" onclick="location.href='/panel/registro/${r.id}'"><td><div class="pac"><span class="avatar">${esc(iniciales(r.nombres, r.apellidos))}</span><div><b>${esc(r.nombres + ' ' + r.apellidos)}</b><small>${esc(edad(r.fecha_nacimiento))} años · ${esc(r.sexo)}</small></div></div></td><td><span class="badge">${esc(r.especialidad)}</span></td><td>${esc(r.documento_numero)}</td><td>${esc(r.telefono)}</td><td>${esc(relativo(r.creado_en))}</td><td class="mono">${esc(r.folio)}</td></tr>`).join('')}
</tbody></table></div></div>` : `<div class="card vacio">${ico('search', 34)}<br><br><strong>No se encontraron registros</strong><br>Pruebe con otro nombre o quite los filtros.<br><br><a class="btn btn-ghost" href="/panel">Ver todos</a></div>`}
${paginas > 1 ? `<div class="pager">${pagina > 1 ? `<a class="btn btn-ghost" href="${href(pagina - 1)}">${ico('back', 18)} Anterior</a>` : ''}<span>Página ${pagina} de ${paginas}</span>${pagina < paginas ? `<a class="btn btn-ghost" href="${href(pagina + 1)}">Siguiente ${ico('arrow', 18)}</a>` : ''}</div>` : ''}`;
  return layout({ titulo: 'Registros', cuerpo, ses, activo: 'registros' });
}

function ficha(ses, r) {
  const espec = ESP.find((e) => e.nombre === r.especialidad);
  const etiquetas = {};
  if (espec) espec.secciones.forEach((sec) => sec.campos.forEach((c) => { etiquetas[c.name] = c.label; }));
  let datos = {}; try { datos = JSON.parse(r.datos_especificos || '{}'); } catch (_) { /* vacío */ }
  const item = (l, v) => (v ? `<div><strong>${esc(l)}</strong>${esc(v)}</div>` : '');
  const clinicos = Object.entries(datos).filter(([, v]) => (Array.isArray(v) ? v.length : v !== '')).map(([k, v]) => item(etiquetas[k] || k.replace(/_/g, ' '), Array.isArray(v) ? v.join(', ') : v)).join('');
  const tieneAlergia = r.alergias && !/^(ninguna|no|n\/a|ninguno|-)\.?$/i.test(r.alergias.trim());
  const doc = [r.documento_tipo && r.documento_tipo !== 'Documento' ? r.documento_tipo : '', r.documento_numero].filter(Boolean).join(' ');
  const contacto = [r.contacto_emergencia_nombre, r.contacto_emergencia_telefono].filter(Boolean).join(' · ');
  const cuerpo = `<div style="--c:${colorDe(r.especialidad)}">
<div class="solo-print"><h2>${esc(cfg('institucion_nombre') || APP_NAME)}</h2><small>Ficha de admisión</small></div>
${encabezado({ titulo: 'Ficha del paciente', volver: ['/panel', 'Volver a registros'], acciones: `<button class="btn btn-primary" onclick="window.print()">${ico('printer', 19)} Imprimir ficha</button>` })}
<section class="perfil"><span class="avatar">${esc(iniciales(r.nombres, r.apellidos))}</span><div class="perfil-info"><h1>${esc(r.nombres + ' ' + r.apellidos)}</h1>
<div class="meta"><span class="badge">${esc(r.especialidad)}</span><span class="pill">${esc(edad(r.fecha_nacimiento))} años</span><span class="pill">${esc(r.sexo)}</span>${r.tipo_sangre ? `<span class="pill sangre">Sangre ${esc(r.tipo_sangre)}</span>` : ''}<span class="pill mono">${esc(r.folio)}</span><span class="pill">${ico('clock', 14)} ${esc(fechaHora(r.creado_en))}</span></div></div></section>
${tieneAlergia ? `<div class="alergia">${ico('alert', 24)}<div>Alergias: ${esc(r.alergias)}</div></div>` : ''}
<div class="cards-2"><div class="card"><h2>${ico('users', 22)} Datos del paciente</h2><div class="ficha-grid">${item('Documento', doc)}${item('Fecha de nacimiento', r.fecha_nacimiento.split('-').reverse().join('/'))}${item('Teléfono', r.telefono)}${item('Correo', r.correo)}${item('Dirección', r.direccion)}</div></div>
<div class="card"><h2>${ico('shield', 22)} Emergencia y salud</h2><div class="ficha-grid">${item('Contacto de emergencia', contacto)}${item('Alergias', r.alergias || 'No indicadas')}${item('Seguro médico', r.seguro_medico)}</div></div></div>
<div class="card" style="margin-top:20px"><h2>${ico('pulse', 22)} Información clínica — ${esc(r.especialidad)}</h2><div class="ficha-grid">${clinicos || '<div>Sin datos adicionales.</div>'}</div></div></div>`;
  return layout({ titulo: 'Ficha ' + r.folio, cuerpo, ses, activo: 'registros' });
}

const ultimoRespaldo = () => (cfg('ultimo_respaldo') ? `<br><small>Última copia descargada: ${esc(fechaHora(cfg('ultimo_respaldo')))}</small>` : '');

function ajustes(ses, { errores = [], ok = '' } = {}) {
  const f = (n, l, t = 'text') => `<div class="field"><label for="${n}">${l}</label><input type="${t}" id="${n}" name="${n}" value="${esc(cfg(n))}"></div>`;
  const cuerpo = `${encabezado({ titulo: 'Ajustes', sub: 'Datos de la institución, seguridad y copias de seguridad.' })}
${alerta(errores)}${aviso(ok)}
<div class="ajustes">
<form class="card" method="post" action="/panel/ajustes/institucion"><input type="hidden" name="csrf" value="${esc(ses.csrf)}"><h2>${ico('home', 22)} Datos de la institución</h2>
<div class="grid"><div class="field full"><label for="institucion_nombre">Nombre del hospital o clínica</label><input type="text" id="institucion_nombre" name="institucion_nombre" value="${esc(cfg('institucion_nombre'))}"></div>
${f('telefono_admision', 'Teléfono de admisión', 'tel')}${f('telefono_urgencias', 'Teléfono de urgencias', 'tel')}${f('correo', 'Correo de contacto', 'email')}${f('direccion', 'Dirección')}</div>
<div class="acciones-fila"><button class="btn btn-primary" type="submit">${ico('check', 19)} Guardar datos</button></div></form>

<form class="card" method="post" action="/panel/ajustes/clave"><input type="hidden" name="csrf" value="${esc(ses.csrf)}"><h2>${ico('lock', 22)} Cambiar contraseña</h2>
<div class="grid"><div class="field full"><label for="actual">Contraseña actual</label><input type="password" id="actual" name="actual" required></div>
<div class="field"><label for="nueva">Nueva contraseña <span class="hint">(mín. 8)</span></label><input type="password" id="nueva" name="nueva" required minlength="8"></div>
<div class="field"><label for="nueva2">Repetir nueva contraseña</label><input type="password" id="nueva2" name="nueva2" required minlength="8"></div></div>
<div class="acciones-fila"><button class="btn btn-primary" type="submit">Cambiar contraseña</button></div></form>

<div class="card" id="respaldo"><h2>${ico('shield', 22)} Copia de seguridad</h2>
<p style="color:var(--muted);margin-top:0">Descargue una copia de todos los registros y guárdela en una memoria USB o en la nube. Se recomienda hacerlo a diario.${ultimoRespaldo()}</p>
<a class="btn btn-primary" href="/panel/respaldo">${ico('download', 19)} Descargar copia de seguridad</a>
<hr class="sep"><p style="color:var(--muted);margin-top:0">Restaurar reemplaza <strong>todos</strong> los registros actuales por los de la copia.</p>
<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center"><input type="file" id="archivo" accept=".sqlite" style="max-width:340px"><button class="btn btn-ghost" type="button" onclick="restaurar()">Restaurar copia</button></div></div></div>
<script>
async function restaurar(){
  const f=document.getElementById('archivo').files[0];
  if(!f){alert('Seleccione primero el archivo de la copia (.sqlite).');return;}
  if(!confirm('Se reemplazarán TODOS los registros actuales por los de la copia. ¿Continuar?'))return;
  const r=await fetch('/panel/restaurar',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-CSRF':${JSON.stringify(ses.csrf)}},body:await f.arrayBuffer()});
  alert(await r.text()); if(r.ok) location.href='/panel';
}
</script>`;
  return layout({ titulo: 'Ajustes', cuerpo, ses, activo: 'ajustes' });
}

/* ---------- Registros del día ---------- */
function hoy(ses, { fecha, esHoy, filas, porEsp }) {
  const [y, m, d] = fecha.split('-');
  const chips = porEsp.map((e) => `<span class="badge" style="--c:${e.color}">${esc(e.nombre)} · ${e.n}</span>`).join(' ');
  const exportar = '/panel/exportar.csv?' + new URLSearchParams({ fecha }).toString();
  const cuerpo = `${encabezado({ titulo: esHoy ? 'Registros de hoy' : `Registros del ${d}/${m}/${y}`,
    sub: `${filas.length} paciente${filas.length === 1 ? '' : 's'} registrado${filas.length === 1 ? '' : 's'}${esHoy ? ' · se actualiza solo cada 30 segundos' : ''}`,
    acciones: `<label class="fecha-sel no-print">${ico('calendar', 19)}<input type="date" value="${esc(fecha)}" max="${hoyISO()}" onchange="location.href='/hoy?fecha='+this.value" aria-label="Ver otro día"></label>
<button class="btn btn-ghost no-print" onclick="window.print()">${ico('printer', 19)} Imprimir lista</button>
<a class="btn btn-ghost no-print" href="${esc(exportar)}">${ico('download', 19)} Exportar</a>` })}
${chips ? `<div class="filtros">${chips}</div>` : ''}
${filas.length ? `<div class="tabla-card"><div class="table-wrap"><table class="reg"><thead><tr><th>Hora</th><th>Paciente</th><th>Especialidad</th><th>Documento</th><th>Teléfono</th><th>Folio</th></tr></thead><tbody>
${filas.map((r) => `<tr class="fila" style="--c:${colorDe(r.especialidad)}" onclick="location.href='/panel/registro/${r.id}'"><td><b>${esc(String(r.creado_en).slice(11, 16))}</b></td><td><div class="pac"><span class="avatar">${esc(iniciales(r.nombres, r.apellidos))}</span><div><b>${esc(r.nombres + ' ' + r.apellidos)}</b><small>${esc(edad(r.fecha_nacimiento))} años · ${esc(r.sexo)}</small></div></div></td><td><span class="badge">${esc(r.especialidad)}</span></td><td>${esc(r.documento_numero)}</td><td>${esc(r.telefono)}</td><td class="mono">${esc(r.folio)}</td></tr>`).join('')}
</tbody></table></div></div>`
    : `<div class="card vacio">${ico('today', 40)}<br><br><strong>${esHoy ? 'Aún no hay registros hoy' : 'No hubo registros ese día'}</strong><br>${esHoy ? 'Los pacientes que registre aparecerán aquí al instante.' : 'Pruebe con otra fecha.'}<br><br><a class="btn btn-primary" href="/nuevo">${ico('userplus', 19)} Nuevo registro</a></div>`}
${esHoy ? '<script>setTimeout(function(){location.reload()},30000)</script>' : ''}`;
  return layout({ titulo: 'Registros de hoy', cuerpo, ses, activo: 'hoy' });
}

/* ---------- Base de datos (todas las columnas) ---------- */
function base(ses, { filas, total, pagina, paginas, q, tam, ruta, puedeAbrir }) {
  const href = (p) => '/panel/base?' + new URLSearchParams({ q, pagina: p }).toString();
  const kb = tam > 1048576 ? (tam / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(tam / 1024)) + ' KB';
  const etiquetas = {};
  ESP.forEach((e) => e.secciones.forEach((sec) => sec.campos.forEach((c) => { etiquetas[c.name] = c.label; })));
  const resumen = (json) => { let d = {}; try { d = JSON.parse(json || '{}'); } catch (_) { return ''; } return Object.entries(d).filter(([, v]) => (Array.isArray(v) ? v.length : v !== '')).map(([k, v]) => `${etiquetas[k] || k}: ${Array.isArray(v) ? v.join('/') : v}`).join(' · '); };
  const hay = (campo) => filas.some((r) => r[campo]);
  const extra = [['correo', 'Correo'], ['direccion', 'Dirección'], ['seguro_medico', 'Seguro'], ['tipo_sangre', 'Sangre']].filter(([c]) => hay(c));
  const cuerpo = `${encabezado({ titulo: 'Base de datos', sub: 'Todo lo guardado en el programa, de un vistazo: sin buscar archivos.',
    acciones: `${puedeAbrir ? `<button class="btn btn-ghost" onclick="fetch('/panel/abrir-carpeta',{method:'POST',headers:{'X-CSRF':${esc(JSON.stringify(ses.csrf))}}})">${ico('folder', 19)} Abrir carpeta de datos</button>` : ''}
<a class="btn btn-ghost" href="/panel/exportar.csv">${ico('download', 19)} Exportar a Excel</a><a class="btn btn-primary" href="/panel/respaldo">${ico('shield', 19)} Copia de seguridad</a>` })}
<div class="info-bd"><div class="info-card"><b>${total}</b><span>registro${total === 1 ? '' : 's'}${q ? ' encontrados' : ' en total'}</span></div><div class="info-card"><b>${esc(kb)}</b><span>tamaño de la base</span></div><div class="info-card ancha"><b class="mono">${esc(ruta)}</b><span>ubicación de los datos en este equipo</span></div></div>
<form class="search" method="get" action="/panel/base">${ico('search', 22)}<input type="search" name="q" value="${esc(q)}" placeholder="Filtrar la base de datos por nombre, documento o folio…"></form>
${filas.length ? `<div class="tabla-card"><div class="table-wrap alto"><table class="reg bd"><thead><tr><th>#</th><th>Folio</th><th>Fecha</th><th>Especialidad</th><th>Nombres</th><th>Apellidos</th><th>Documento</th><th>Nacimiento</th><th>Sexo</th><th>Teléfono</th><th>Contacto de emergencia</th><th>Alergias</th>${extra.map(([, t]) => `<th>${t}</th>`).join('')}<th>Datos clínicos</th></tr></thead><tbody>
${filas.map((r) => `<tr><td class="mono">${r.id}</td><td class="mono">${esc(r.folio)}</td><td>${esc(fechaHora(r.creado_en))}</td><td>${esc(r.especialidad)}</td><td>${esc(r.nombres)}</td><td>${esc(r.apellidos)}</td><td>${esc(r.documento_numero)}</td><td>${esc(String(r.fecha_nacimiento).split('-').reverse().join('/'))}</td><td>${esc(r.sexo)}</td><td>${esc(r.telefono)}</td><td>${esc([r.contacto_emergencia_nombre, r.contacto_emergencia_telefono].filter(Boolean).join(' · '))}</td><td>${esc(r.alergias)}</td>${extra.map(([c]) => `<td>${esc(r[c])}</td>`).join('')}<td class="clin" title="${esc(resumen(r.datos_especificos))}">${esc(resumen(r.datos_especificos))}</td></tr>`).join('')}
</tbody></table></div></div>` : `<div class="card vacio">${ico('database', 40)}<br><br><strong>${q ? 'Sin coincidencias' : 'La base de datos está vacía'}</strong><br>${q ? 'Pruebe con otro texto.' : 'Los registros guardados aparecerán aquí.'}</div>`}
${paginas > 1 ? `<div class="pager">${pagina > 1 ? `<a class="btn btn-ghost" href="${href(pagina - 1)}">${ico('back', 18)} Anterior</a>` : ''}<span>Página ${pagina} de ${paginas}</span>${pagina < paginas ? `<a class="btn btn-ghost" href="${href(pagina + 1)}">Siguiente ${ico('arrow', 18)}</a>` : ''}</div>` : ''}`;
  return layout({ titulo: 'Base de datos', cuerpo, ses, activo: 'base' });
}

function noEncontrado(ses) {
  return layout({ titulo: 'No encontrado', cuerpo: `<div class="ok-wrap"><h1>Página no encontrada</h1><p>La dirección que buscaba no existe.</p><a class="btn btn-primary" href="/">Volver al inicio</a></div>`, ses });
}

module.exports = { hoy, base, inicio, nuevo, formulario, gracias, instalar, login, panel, ficha, ajustes, noEncontrado };
