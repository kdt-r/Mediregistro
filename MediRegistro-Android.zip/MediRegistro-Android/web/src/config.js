'use strict';
const Store = require('./store');

const APP_NAME = 'MediRegistro';
const APP_VERSION = __APP_VERSION__;
const ITER = 210000;

let datos = {};

async function iniciar() { datos = (await Store.get('config')) || {}; }
const guardar = () => Store.set('config', JSON.parse(JSON.stringify(datos)));
const cfg = (k, def = '') => (datos[k] !== undefined && datos[k] !== '' ? String(datos[k]) : def);
const instalado = () => !!datos.admin_user && !!datos.admin_hash;
async function actualizar(cambios) { Object.assign(datos, cambios); await guardar(); }

// Contraseñas con PBKDF2-SHA256 (WebCrypto nativo, sin dependencias)
const aHex = (u8) => Array.from(u8, (x) => x.toString(16).padStart(2, '0')).join('');
const deHex = (h) => Uint8Array.from(h.match(/../g) || [], (x) => parseInt(x, 16));
async function derivar(clave, salHex, iter) {
  const llave = await crypto.subtle.importKey('raw', new TextEncoder().encode(clave), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: deHex(salHex), iterations: iter }, llave, 256);
  return aHex(new Uint8Array(bits));
}
function iguales(a, b) { // comparación en tiempo constante
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
async function hashClave(clave) {
  const sal = aHex(crypto.getRandomValues(new Uint8Array(16)));
  return `pbkdf2$${ITER}$${sal}$${await derivar(clave, sal, ITER)}`;
}
async function claveValida(clave, almacenado) {
  const [alg, it, sal, hash] = String(almacenado || '').split('$');
  if (alg !== 'pbkdf2' || !it || !sal || !hash) return false;
  return iguales(await derivar(clave, sal, Number(it)), hash);
}

module.exports = { APP_NAME, APP_VERSION, iniciar, cfg, instalado, actualizar, hashClave, claveValida, iguales };
