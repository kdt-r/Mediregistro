package com.mediregistro.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;

/**
 * Contenedor de MediRegistro: un WebView que sirve la aplicación desde assets/ (sin servidor, sin internet).
 * Aporta lo que un WebView no hace solo: guardar archivos, elegir archivos, imprimir y el botón "atrás".
 */
public class MainActivity extends Activity {

    /** Poner en true para impedir capturas de pantalla (datos sensibles de pacientes). */
    private static final boolean BLOQUEAR_CAPTURAS = false;

    private static final String HOST = "appassets.androidplatform.net";
    private static final int PEDIDO_GUARDAR = 1;
    private static final int PEDIDO_ELEGIR = 2;

    private WebView web;
    private ValueCallback<Uri[]> selectorArchivo;
    private byte[] archivoPendiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (BLOQUEAR_CAPTURAS) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        }

        final WebViewAssetLoader cargador = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // necesario para IndexedDB (aquí se guardan los datos)
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return cargador.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignorada) { }
                return true; // nunca se navega fuera de la app dentro del WebView
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (selectorArchivo != null) selectorArchivo.onReceiveValue(null);
                selectorArchivo = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Seleccione la copia de seguridad"), PEDIDO_ELEGIR);
                } catch (Exception e) {
                    selectorArchivo = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String mensaje, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(mensaje)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String mensaje, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(mensaje)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        web.addJavascriptInterface(new Puente(), "AndroidBridge");
        web.loadUrl("https://" + HOST + "/index.html");
    }

    /** Funciones nativas que la página llama como AndroidBridge.xxx() */
    private class Puente {
        /** Guarda un archivo (copia de seguridad, Excel) donde la persona elija: Descargas, Drive, USB… */
        @JavascriptInterface
        public void saveFile(String nombre, String mime, String base64) {
            try {
                archivoPendiente = Base64.decode(base64, Base64.DEFAULT);
            } catch (IllegalArgumentException e) {
                return;
            }
            final Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_TITLE, nombre);
            runOnUiThread(() -> startActivityForResult(i, PEDIDO_GUARDAR));
        }

        /** Imprime la pantalla actual (o la guarda como PDF) con el diálogo de impresión de Android. */
        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                String nombre = "MediRegistro";
                pm.print(nombre, web.createPrintDocumentAdapter(nombre), new PrintAttributes.Builder().build());
            });
        }
    }

    @Override
    protected void onActivityResult(int pedido, int resultado, Intent datos) {
        super.onActivityResult(pedido, resultado, datos);
        if (pedido == PEDIDO_GUARDAR) {
            byte[] bytes = archivoPendiente;
            archivoPendiente = null;
            if (resultado == RESULT_OK && datos != null && datos.getData() != null && bytes != null) {
                try (OutputStream os = getContentResolver().openOutputStream(datos.getData(), "wt")) {
                    os.write(bytes);
                    Toast.makeText(this, "Archivo guardado", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el archivo", Toast.LENGTH_LONG).show();
                }
            }
        } else if (pedido == PEDIDO_ELEGIR && selectorArchivo != null) {
            Uri[] elegido = null;
            if (resultado == RESULT_OK && datos != null && datos.getData() != null) {
                elegido = new Uri[]{datos.getData()};
            }
            selectorArchivo.onReceiveValue(elegido);
            selectorArchivo = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
