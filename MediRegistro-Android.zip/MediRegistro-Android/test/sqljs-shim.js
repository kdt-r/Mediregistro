'use strict';
// Imita la parte de la API de sql.js que usa MediRegistro, apoyándose en node:sqlite (solo para pruebas).
const { DatabaseSync } = require('node:sqlite');

class Statement {
  constructor(db, sql) { this.st = db.prepare(sql); this.params = []; this.filas = null; this.i = 0; }
  bind(p) { this.params = p || []; return true; }
  step() { if (!this.filas) this.filas = this.st.all(...this.params); return this.i < this.filas.length && (this.i++, true); }
  getAsObject() { return { ...this.filas[this.i - 1] }; }
  free() {}
}

class Database {
  constructor(bytes) {
    this.d = new DatabaseSync(':memory:');
    if (bytes) {
      let dump;
      try { dump = JSON.parse(Buffer.from(bytes).toString('utf8')); } catch (_) { throw new Error('file is not a database'); }
      dump.schema.forEach((s) => this.d.exec(s));
      for (const [t, filas] of Object.entries(dump.filas)) {
        for (const f of filas) {
          const cols = Object.keys(f);
          this.d.prepare(`INSERT INTO ${t} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`).run(...cols.map((c) => f[c]));
        }
      }
    }
  }
  run(sql, params) { if (params && params.length) this.d.prepare(sql).run(...params); else this.d.exec(sql); }
  prepare(sql) { return new Statement(this.d, sql); }
  exec(sql) {
    const filas = this.d.prepare(sql).all();
    return filas.length ? [{ columns: Object.keys(filas[0]), values: filas.map((f) => Object.values(f)) }] : [];
  }
  export() {
    const schema = this.d.prepare("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY type DESC").all().map((r) => r.sql);
    const tablas = this.d.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map((r) => r.name);
    const filas = {}; tablas.forEach((t) => { filas[t] = this.d.prepare(`SELECT * FROM ${t}`).all().map((f) => ({ ...f })); });
    return new Uint8Array(Buffer.from(JSON.stringify({ schema, filas })));
  }
  close() { this.d.close(); }
}

module.exports = { Database };
