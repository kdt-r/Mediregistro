'use strict';
// Empaqueta web/ en android/app/src/main/assets (HTML + JS + sql.js).  Uso: node build-web.js
const fs = require('fs');
const path = require('path');

const RAIZ = __dirname;
const SRC = path.join(RAIZ, 'web', 'src');
const SALIDA = path.join(RAIZ, 'android', 'app', 'src', 'main', 'assets');
const VERSION = require('./package.json').version;
const MODULOS = ['store', 'config', 'db', 'especialidades', 'vistas', 'router', 'boot'];

function empaquetar() {
  let out = `(function (global) {\n'use strict';\nconst defs = {}, cache = {};\n` +
    `function req(n) {\n  const k = n.replace(/^(\\.{1,2}\\/)+/, '').replace(/\\.js$/, '');\n` +
    `  if (cache[k]) return cache[k].exports;\n  if (!defs[k]) throw new Error('Módulo no encontrado: ' + n);\n` +
    `  const m = { exports: {} }; cache[k] = m; defs[k](m, m.exports, req); return m.exports;\n}\n`;
  for (const m of MODULOS) {
    const codigo = fs.readFileSync(path.join(SRC, m + '.js'), 'utf8').split('__APP_VERSION__').join(JSON.stringify(VERSION));
    out += `defs[${JSON.stringify(m)}] = function (module, exports, require) {\n${codigo}\n};\n`;
  }
  out += `global.MediRegistro = { require: req };\n` +
    `if (typeof document !== 'undefined' && document.getElementById('mr-carga')) req('boot');\n` +
    `})(typeof window !== 'undefined' ? window : globalThis);\n`;
  return out;
}

function copiar(origen, destino) {
  fs.mkdirSync(path.dirname(destino), { recursive: true });
  fs.copyFileSync(origen, destino);
}

function construir() {
  const sqljs = path.join(RAIZ, 'node_modules', 'sql.js', 'dist');
  for (const f of ['sql-wasm.js', 'sql-wasm.wasm']) {
    if (!fs.existsSync(path.join(sqljs, f))) throw new Error('Falta sql.js. Ejecute primero:  npm install');
  }
  fs.rmSync(SALIDA, { recursive: true, force: true });
  fs.mkdirSync(SALIDA, { recursive: true });
  fs.writeFileSync(path.join(SALIDA, 'app.js'), empaquetar());
  copiar(path.join(RAIZ, 'web', 'index.html'), path.join(SALIDA, 'index.html'));
  copiar(path.join(sqljs, 'sql-wasm.js'), path.join(SALIDA, 'sql-wasm.js'));
  copiar(path.join(sqljs, 'sql-wasm.wasm'), path.join(SALIDA, 'sql-wasm.wasm'));
  const pub = path.join(RAIZ, 'web', 'public');
  const recorrer = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = path.join(d, e.name);
    if (e.isDirectory()) recorrer(p); else copiar(p, path.join(SALIDA, path.relative(pub, p)));
  });
  recorrer(pub);
  console.log('Web empaquetada en', SALIDA);
}

module.exports = { empaquetar };
if (require.main === module) construir();
